<?php
/**
 * The Header for multipage of theme
 *
 * Displays all of the <head> section and everything up till </header>
 *
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<?php $preloader = (function_exists('ot_get_option'))? ot_get_option( 'preloader', 'off' ) : 'off'; ?>
    <?php if($preloader == 'on'): ?>
		<div id="preloader-active">
			<div class="preloader d-flex align-items-center justify-content-center">
				<div class="preloader-inner position-relative">
				<div class="flip-square"></div>
				</div>
			</div>
		</div>
    <?php endif; ?>

    <div id="wrapper">
        <?php
        $overwrite_header_style = get_post_meta(get_the_ID(), 'overwrite_header_style', true);
		$display_banner 		= get_post_meta(get_the_ID(), 'display_banner', true);
        if($overwrite_header_style == 'on'){
            $header_style = get_post_meta(get_the_ID(), 'page_header_style', true);
        }else{
            $header_style = (function_exists('ot_get_option'))? ot_get_option( 'header_style', 'style1' ) : 'style1';
        }        

        get_template_part( 'header/header', $header_style );

        if( is_page_template( 'page-templates/home-page.php' ) ) {
		} else {
			if( is_page() ) {
				if( $display_banner != 'off' ) {
					get_template_part( 'header/banner', '' );
				}
			}
			else {
				get_template_part( 'header/banner', '' );
			}
		}

        