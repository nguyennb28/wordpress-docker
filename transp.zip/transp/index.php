<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme and one
 * of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query,
 * e.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 */

get_header(); ?>

	<?php get_template_part( 'layout/before', '' ); ?>

		<?php
			if ( have_posts() ) :
				// Start the Loop.
				$blog_style = (function_exists('ot_get_option'))? ot_get_option( 'blog_style', 'default' ) : 'default';
				if($blog_style == 'grid_view'):
				?>
                <div class="row blog-grid">
                <?php
				endif;
				
				while ( have_posts() ) : the_post();

					/*
					 * Include the post format-specific template for the content. If you want to
					 * use this in a child theme, then include a file called called content-___.php
					 * (where ___ is the post format) and that will be used instead.
					 */
					get_template_part( 'content', get_post_format() );

				endwhile;
				if($blog_style == 'grid_view'):
				?>
                </div>
                <?php				
				endif;
				
				transp_posts_nav();

			else :
				// If no content, include the "No posts found" template.
				get_template_part( 'content', 'none' );

			endif;
		?>       
            
	<?php get_template_part( 'layout/after', '' ); ?>
    
<?php get_footer(); ?>