<header id="header" class="header tra-menu navbar-light">
    <div class="header-wrapper">
        <?php
        $logo = (function_exists('ot_get_option'))? ot_get_option( 'main_logo', TRANSPTHEMEURI . 'images/logo.svg' ) : TRANSPTHEMEURI . 'images/logo.svg';
        $mobile_logo = (function_exists('ot_get_option'))? ot_get_option( 'mobile_logo', TRANSPTHEMEURI . 'images/logo-white.svg' ) : TRANSPTHEMEURI . 'images/logo-white.svg'; 
        ?>

        <!-- MOBILE HEADER -->
        <div class="wsmobileheader clearfix">	  	
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><span class="smllogo"><img src="<?php echo esc_attr($mobile_logo); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" /></span></a>
            <a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>	
        </div>

        <!-- NAVIGATION MENU -->
        <div class="wsmainfull menu clearfix">
            <div class="wsmainwp clearfix">

                <!-- HEADER LOGO -->
                <div class="desktoplogo">
                    <a class="logo-black" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
                        <?php if($logo != ''): ?>
                            <img src="<?php echo esc_attr($logo); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
                        <?php else: ?>
                            <?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?>
                        <?php endif; ?>
                    </a>
                </div>
                <div class="desktoplogo">
                    <a class="logo-white" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
                        <?php if($mobile_logo != ''): ?>
                            <img src="<?php echo esc_attr($mobile_logo); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
                        <?php else: ?>
                            <?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?>
                        <?php endif; ?>
                    </a>
                </div>

                <!-- MAIN MENU -->
                <nav class="wsmenu clearfix">
                    <?php $header_button = (function_exists('ot_get_option'))? ot_get_option( 'call_to_action_text', '' ) : '';
                    $header_button_link = (function_exists('ot_get_option'))? ot_get_option( 'call_to_action_number', '' ) : '';
                    $extra_links = '';
                    if( $header_button != '' && $header_button_link != '' ):
                        $extra_links = '<li class="nl-simple header-phone">
                            <a href="'.esc_url($header_button_link).'" class="last-link"><span class="bg-color-09 white-color"><i class="cs-icon cs-087-phone-call"></i></span>'.esc_html($header_button).'</a>
                        </li>';
                    endif;
                    ?>
                    <?php
                    if ( is_page_template( 'page-templates/one-page.php' ) ) {
                        $menu_name = get_post_meta( get_the_ID(), 'onepage_menu_select', true );	
                        wp_nav_menu(
                            array(
                            'menu' 			  => $menu_name,
                            'theme_location' => 'main-menu',
                            'menu_class' => 'wsmenu-list nav-skyblue-hover',
                            'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s'.$extra_links.'</ul>',
                            'container' => false,
                            'fallback_cb'     => '',
                            'walker' => new transp_scm_walker
                            )
                        );
                    } else {							
                        wp_nav_menu(
                            array(
                                'theme_location' => 'main-menu',
                                'menu_class' => 'wsmenu-list nav-skyblue-hover',
                                'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s'.$extra_links.'</ul>',
                                'container' => false,
                                'fallback_cb'     => '',
                                'walker' => new transp_scm_walker
                            )
                        );
                    }
                    ?>  
                </nav>	<!-- END MAIN MENU -->
            </div>
        </div>	<!-- END NAVIGATION MENU -->
    </div>     <!-- End header-wrapper -->
</header>	<!-- END HEADER -->