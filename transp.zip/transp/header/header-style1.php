<?php
  $logo                     = (function_exists('ot_get_option'))? ot_get_option( 'main_logo', TRANSPTHEMEURI . 'images/logo.svg' ) : TRANSPTHEMEURI . 'images/logo.svg';
  $mobile_logo              = (function_exists('ot_get_option'))? ot_get_option( 'mobile_logo', TRANSPTHEMEURI . 'images/logo-white.svg' ) : TRANSPTHEMEURI . 'images/logo-white.svg';  
  $header_button            = (function_exists('ot_get_option'))? ot_get_option( 'header_button', '' ) : '';
  $header_button_link       = (function_exists('ot_get_option'))? ot_get_option( 'header_button_link', '' ) : '';
  $show_topbar              = (function_exists('ot_get_option'))? ot_get_option( 'show_topbar', 'on' ) : 'on';
  $login_button_in_menu     = (function_exists('ot_get_option'))? ot_get_option( 'login_button_in_menu', 'on' ) : 'on';
  $call_to_action_text      = (function_exists('ot_get_option'))? ot_get_option( 'call_to_action_text', '' ) : '';
  $call_to_action_number    = (function_exists('ot_get_option'))? ot_get_option( 'call_to_action_number', '' ) : '';
  $email_for_topbar         = (function_exists('ot_get_option'))? ot_get_option( 'email_for_topbar', '' ) : '';
  $show_language_dropdown   = (function_exists('ot_get_option'))? ot_get_option( 'show_language_dropdown', 'off' ) : 'off';
  $social_array             = (function_exists('ot_get_option'))? ot_get_option( 'header_social_icons', array() ) : array();
  $full_width_class         = '';

 if( ( 'on' == $show_language_dropdown ) || ( $login_button_in_menu == 'on' && class_exists( 'woocommerce' ) ) || ( $header_button != '' && $header_button_link != '' ) ){
  $full_width_class = ' no-header-right';
 }
?>
<?php if($show_topbar != 'off'): ?>
  <?php if( ( $call_to_action_text != '' && $call_to_action_number != '' ) || ( $email_for_topbar != '' ) || ( ! empty( $social_array ) ) ): ?>
    <div class="box-bar bg-grey-900">
      <div class="container position-relative">
        <div class="row align-items-center"> 
          <div class="col-lg-7 col-md-8 col-sm-5 col-4">
            <?php if( $call_to_action_text != '' && $call_to_action_number != '' ): ?>
              <a class="phone-icon mr-45" href="tel:<?php echo esc_attr( $call_to_action_number ); ?>">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"></path>
                </svg><?php echo esc_html( $call_to_action_text ); ?>
              </a>
            <?php endif; ?>
            
            <?php if( $email_for_topbar != '' ): ?>
              <a class="email-icon" href="mailto:<?php echo esc_attr( $email_for_topbar ); ?>">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"></path>
                </svg><?php echo esc_html( $email_for_topbar ); ?>
              </a>
            <?php endif; ?>
          </div>
          <div class="col-lg-5 col-md-4 col-sm-7 col-8 text-end">
            <?php	if( ! empty( $social_array ) ): ?>                        
                <?php foreach ( $social_array as $key => $value ): ?>
                    <a class="icon-socials icon-twitter2" href="<?php echo esc_url( $value['link'] ); ?>" target="_blank" rel="noopener"  title="<?php echo esc_attr( $value['title'] ); ?>">                            
                      <i class="<?php echo esc_attr( $value['social_class'] ); ?>"></i>
                    </a>
                <?php endforeach; ?>		
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
<?php endif; ?>

<header class="header sticky-bar">
  <div class="container">
    <div class="main-header">
      <!-- start mobile menu -->
      <div class="mobile-menu">
        <div class="menu-backdrop"></div>
          <div class="close-btn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/></svg></div>
          <nav class="menu-box">
              <div class="nav-logo">
                  <a class="mobile-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
                    <?php if( $logo != '' ): ?>
                        <img src="<?php echo esc_attr( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
                    <?php else: ?>
                        <?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?>
                    <?php endif; ?>
                  </a>
              </div>
              
              <div class="menu-outer"></div>
              <?php if( $header_button != '' && $header_button_link != '' ): ?>
                <a class="btn btn-brand-1 d-none d-xl-inline-block hover-up" href="<?php echo esc_url( $header_button_link ); ?>">
                  <svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z"> </path></svg>
                  <?php echo esc_html( $header_button ); ?>
                </a>
              <?php endif; ?>

          </nav>          
      </div>

      <!-- end mobile menu -->

      <div class="header-left<?php echo esc_attr( $full_width_class ); ?>">
        <div class="header-logo">
          <a class="d-flex" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
              <?php if( $logo != '' ): ?>
                  <img src="<?php echo esc_attr( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
              <?php else: ?>
                  <?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?>
              <?php endif; ?>
          </a>            
        </div>
        <div class="header-nav">
        <nav class="nav-main-menu d-none d-xl-block">
          <?php
            wp_nav_menu(
              array(
              'theme_location'  => 'main-menu',
              'menu_class'      => 'main-menu',
              'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
              'container'       => false,
              'fallback_cb'     => '',
              'walker'          => new transp_scm_walker
              )
            );
          ?>
         </nav>
          
          <!-- mobile menu -->
          <div class="mobile-nav-toggler burger-icon burger-icon-white"><span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>

        </div>

        <?php if( ( 'on' == $show_language_dropdown ) || ( $login_button_in_menu == 'on' && class_exists( 'woocommerce' ) ) || ( $header_button != '' && $header_button_link != '' ) ): ?>
        <div class="header-right">
          <?php if( 'on' == $show_language_dropdown ): ?>
            <div class="d-inline-block box-dropdown-cart"><span class="font-lg icon-list icon-account"><span class="font-sm color-grey-900 arrow-down"> 
                  <svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418"></path>
                  </svg><?php echo esc_html__( 'English', 'transp' ); ?></span></span>
              <div class="dropdown-account">
                <ul>
                  <li><a class="font-md" href="#"><img src="<?php echo esc_url(TRANSPTHEMEURI); ?>/images/en.png" alt="<?php echo esc_attr__('English', 'transp'); ?>">
                      <?php echo esc_html__( 'English', 'transp' ); ?></a></li>
                  <li><a class="font-md" href="#"><img src="<?php echo esc_url(TRANSPTHEMEURI); ?>/images/fr.png" alt="<?php echo esc_attr__('France', 'transp'); ?>">
                      <?php echo esc_html__( 'French', 'transp' ); ?></a></li>
                  <li><a class="font-md" href="#"><img src="<?php echo esc_url(TRANSPTHEMEURI); ?>/images/cn.png" alt="<?php echo esc_attr__('China', 'transp'); ?>">
                      <?php echo esc_html__( 'Chinese', 'transp' ); ?></a></li>
                </ul>
              </div>
            </div>
          <?php endif; ?>
        
          <div class="d-none d-sm-inline-block">
            <?php if( $login_button_in_menu == 'on' ): 
              if( class_exists( 'woocommerce' ) ):
								$myaccount_page = get_permalink( get_option( 'woocommerce_myaccount_page_id' ) );
                if( is_user_logged_in() ):
                  $login_text = esc_html__( 'My Account', 'transp' );
                else:
                  $login_text = esc_html__( 'Login', 'transp' );
                endif; ?>
                <a class="btn btn-default mr-10 hover-up" href="<?php echo esc_url( $myaccount_page ); ?>">
                  <?php echo esc_html( $login_text ); ?>
                </a>
                <?php 
              endif;
            endif; 
            ?>
            <?php if( $header_button != '' && $header_button_link != '' ): ?>
              <a class="btn btn-brand-1 d-none d-xl-inline-block hover-up" href="<?php echo esc_url( $header_button_link ); ?>">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z"> </path></svg>
                <?php echo esc_html( $header_button ); ?>
              </a>
            <?php endif; ?>
          </div>        
        </div>
      <?php endif; ?>
      </div>
    </div>
  </div>
</header>