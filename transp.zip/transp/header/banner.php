<?php
$title 			= '';
$subtitle 		= '';
$description 	= '';
$bg_class 		= 'bg-snow';

if( is_singular( 'portfolio' ) ) {
	$title 			= get_the_title();
	$subtitle 		= '';
	$description 	= '';
	$custom_title 	= get_post_meta( get_the_ID(), 'port_custom_title', true );
	if( $custom_title == 'on' ){
		$alt_title 			= get_post_meta( get_the_ID(), 'portfolio_title', true );
		$title 				= ( $alt_title != '' )? $alt_title : $title;
		$alt_subtitle 		= get_post_meta( get_the_ID(), 'portfolio_subtitle', true );
		$subtitle 			= ( $alt_subtitle != '' )? $alt_subtitle : $subtitle;
		$alt_description 	= get_post_meta( get_the_ID(), 'portfolio_single_description', true );
		$description    	= ( $alt_description != '' )? $alt_description : $description;
	}
} elseif( is_single() ) {
	$title 			= (function_exists('ot_get_option'))? ot_get_option('blog_single_title', '') : '';
	$subtitle 		= (function_exists('ot_get_option'))? ot_get_option('blog_single_subtitle', '') : '';
	$description 	= (function_exists('ot_get_option'))? ot_get_option('blog_single_description', '') : '';
} elseif( is_home() ){		
	$title 			= (function_exists('ot_get_option'))? ot_get_option('blog_title', '') : '';
	$subtitle 		= (function_exists('ot_get_option'))? ot_get_option('blog_subtitle', '') : '';
	$description 	= (function_exists('ot_get_option'))? ot_get_option('blog_single_description', '') : '';
} elseif ( is_category() ) {
	$title = esc_html__( 'Category Archives: ', 'transp' ).single_cat_title( '', false );
	if ( category_description() ) :
		$subtitle = category_description();
	endif;

} elseif( is_search() ) {
	$title 			= esc_html__('Search Result', 'transp');
	$subtitle 		= esc_html__( 'This is a Search Results Page for: '. get_search_query(), 'transp' );
} elseif ( is_author() ) {
	$title = esc_html__( 'Author Archives: ', 'transp' ).'' . get_the_author() . '';
	if ( category_description() ) :
		$subtitle = category_description();
	endif;
} elseif( is_tag() ) {
	$title = esc_html__( 'Tag Archives: ', 'transp' ).single_tag_title( '', false );
	if ( tag_description() ) :
		$subtitle = tag_description();
	endif;
} elseif ( is_archive() ) {	
		
	if ( is_day() ) :
		$title =  esc_html__( 'Daily Archives: ', 'transp' ).'' . get_the_date() . '';
	elseif ( is_month() ) :
		$title = esc_html__( 'Monthly Archives: ', 'transp' ). '' . get_the_date( esc_html_x( 'F Y', 'monthly archives date format', 'transp' ) ) . '' ;
	elseif ( is_year() ) :
		$title = esc_html__( 'Yearly Archives: ', 'transp' ).'' . get_the_date( esc_html_x( 'Y', 'yearly archives date format', 'transp' ) ) . '' ;
	else :
		$title = esc_html__( 'Archives', 'transp' );
	endif;
} elseif( is_404() ) {
	$title 		= esc_html__('Page Not Found', 'transp');
	$subtitle 	= esc_html__( 'Sorry page not found...', 'transp');
} elseif( is_page() ) {
	$title 			= get_the_title();
	$custom_title 	= get_post_meta( get_the_ID(), 'custom_title', true );
	if( $custom_title == 'on' ) {
		$alt_title 			= get_post_meta( get_the_ID(), 'title', true );
		$title 				= ( $alt_title != '' )? $alt_title : $title;
		$alt_subtitle 		= get_post_meta( get_the_ID(), 'subtitle', true );
		$subtitle 			= ( $alt_subtitle != '' )? $alt_subtitle : $subtitle;
		$alt_description 	= get_post_meta( get_the_ID(), 'page_single_description', true );
		$description 		= ( $alt_description != '' )? $alt_description : $description;
	}
} else {
	$title = get_the_title();
}

if( is_post_type_archive( 'portfolio' ) ) {
	$title 	  		= (function_exists('ot_get_option'))? ot_get_option( 'portfolio_title', '' ) : '';
	$subtitle 		= (function_exists('ot_get_option'))? ot_get_option( 'portfolio_subtitle', '' ) : '';
	$description 	= (function_exists('ot_get_option'))? ot_get_option( 'portfolio_single_description', '' ) : '';
}

if ( class_exists( 'woocommerce' ) ) {
	if( is_product() ) {
		$title 			= (function_exists('ot_get_option'))? ot_get_option('shop_single_title', '') : '';
		$subtitle 		= (function_exists('ot_get_option'))? ot_get_option('shop_single_subtitle', '') : '';
		$description 	= (function_exists('ot_get_option'))? ot_get_option('shop_single_description', '') : '';
	}
	elseif( is_woocommerce() ) {
		$shop_page_id 	= wc_get_page_id( 'shop' );
		$page_title   	= get_the_title( $shop_page_id );
		$title 			= (function_exists('ot_get_option'))? ot_get_option('shop_title', $page_title) : $page_title;
		$subtitle 		= (function_exists('ot_get_option'))? ot_get_option('shop_subtitle', '') : '';
		$description 	= (function_exists('ot_get_option'))? ot_get_option('shop_description', '') : '';
	}
}

$overwrite_header_style = get_post_meta(get_the_ID(), 'overwrite_header_style', true);
if( $overwrite_header_style == 'on' ) {
	$header_style = get_post_meta(get_the_ID(), 'page_header_style', true);
}else {
	$header_style = (function_exists('ot_get_option'))? ot_get_option( 'header_style', 'style1' ) : 'style1';
}

$banner_classes = 'header-'.$header_style.' '.$bg_class;
?>

<?php if( $title != '' || $subtitle != '' ): ?>

	<section class="section bg-banner">

		<div class="container">

			<div class="box-pageheader-1 text-center">

				<?php if( $subtitle != '' ): ?>

					<span class="btn btn-tag wow animate__animated animate__fadeIn"><?php echo wp_kses( $subtitle, array( 'br'=>array() ) ); ?></span>
					
				<?php endif; ?>

				<h2 class="color-brand-1 mt-15 mb-10 wow animate__animated animate__fadeIn"><?php echo esc_html( $title ); ?></h2>

				<?php if( $description != '' ): ?>

					<p class="font-md color-white wow animate__animated animate__fadeIn"><?php echo wp_kses( $description, array( 'br'=>array() ) ); ?></p>

				<?php endif; ?>

				<?php
				$show_breadcrumbs =  (function_exists('ot_get_option'))? ot_get_option('show_breadcrumbs', 'on') : 'on';

				if($show_breadcrumbs == 'on'): ?>

					<div class="breadcrumb-content text-center">

						<?php transp_breadcrumbs(); ?>

					</div>

				<?php endif; ?>

			</div>

		</div>

	</section>

<?php endif; ?>
    
