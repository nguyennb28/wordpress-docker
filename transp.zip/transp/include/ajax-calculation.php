<?php
add_action('wp_ajax_cost_calculation', 'cost_calculation');
add_action('wp_ajax_nopriv_cost_calculation', 'cost_calculation');

function cost_calculation(){
	$post_arr = filter_input_array( INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS );

	if( $post_arr[ 'fields' ] ){

		$fields_arr 		= $post_arr[ 'fields' ];
		$fields 			= json_decode(html_entity_decode($fields_arr));
		$weight 			= ( !empty($fields->calculate_width))? $fields->calculate_width : 0.5;
		$pickup_location    = ( !empty($fields->pickup_location))? $fields->pickup_location : '';
		$delivery_location  = ( !empty($fields->delivery_location))? $fields->delivery_location : '';
		$commodities  		= ( !empty($fields->commodities))? $fields->commodities : '';
		$item_price 		= 0;
		$all_value 			= 0;
		$currency 			= ( class_exists( 'woocommerce' ))? get_woocommerce_currency_symbol() : '$';

		if( function_exists( 'ot_get_option' ) ) {
			$calculate_cost 	= ot_get_option( 'calculate_cost', array() );
			$add_extra_services = ot_get_option( 'add_extra_services', array() );

			foreach ( $calculate_cost as $key => $value ) {
				$service_name 			    	= str_replace(' ', '_', $value['title']). '_' .$key;
				$max_weight  					= $value['max_weight'];					

				if( $service_name == $fields->service_name && $weight <= $max_weight ) {									
					$select_product_to_connect  	= $value['select_product_to_connect'];
					$item_price_val = $value['item_price'];
					$extra_service = $fields->extra_service;
					if( ! empty ( $extra_service ) ) {
						foreach ( $extra_service as $checked ) {
							$all_value = $all_value + $checked;
						}
						$item_price_val = $item_price_val + $all_value;
					}

					if($select_product_to_connect != ''){
						$item_price = '<a href="'.get_permalink( $select_product_to_connect ).'">';
					}

					$item_price .= '<p class="calculate-item-price">'.esc_html__( 'Total Cost: ', 'transp' ).'<span>'. $currency .$item_price_val.'</span></p>';

					if($select_product_to_connect != ''){
						$item_price .= '</a>';
					}

				}
			}

		}

		$data = [
			'price' => $item_price,
			'pickup' => $pickup_location,
			'deliver' => $delivery_location
		];

		$response = array(
			'status_code'  => 200,
			'message'	   => [ esc_html__( 'Cost Calculator form submit successfully', 'transp' ) ],
			'data'		   => $data
		);
	
		wp_send_json_success( $response );

	}

	$response = array(
		'status_code'  => 400,
		'message'	   => [ esc_html__( 'Something is wrong', 'transp' ) ],
		'data'		   => []
	);

	wp_send_json_error( $response );

	wp_die();

}