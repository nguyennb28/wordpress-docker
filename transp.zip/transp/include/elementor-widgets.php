<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if(defined('ELEMENTOR_VERSION')):

class Transp_Elementor_Widgets_Init{
	
    public static $instance;

	/**
     * Load Construct
     * 
     * @since 1.0
     */
	/** Transp Class Constructor **/
	public function __construct(){
		add_action('elementor/init', array($this, 'transp_elementor_category'));
        add_action('elementor/widgets/widgets_registered', array($this, 'transp_all_elements'));
		add_action('elementor/frontend/after_enqueue_scripts', array( $this, 'transp_enqueue_scripts' ) ); 
	}
	
	public static function get_instance(){
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

    /** Enqueue Scripts and Stylesheets **/ 
    
     public function transp_enqueue_scripts() {
		 wp_enqueue_script( 'transp-elementor', TRANSPTHEMEURI . 'js/lib/scripts-elementor.js', [ 'jquery' ], false, true );
    }
	
	/** Elementor add category **/

    public function transp_elementor_category(){    
		\Elementor\Plugin::$instance->elements_manager->add_category(
			'transp-all-elements',
			[
				'title' =>esc_html__( 'Transp', 'transp' ),
				'icon' => 'fas fa-hand-holding-usd',
			],
			1
		);
    }

	public function transp_all_elements($elements){

		require_once TRANSPTHEMEDIR .'include/elements/image.php';
		$elements->register_widget_type(new Elementor\Transp_Image());

		require_once TRANSPTHEMEDIR .'include/elements/text-editor.php';
		$elements->register_widget_type(new Elementor\Transp_TextEditor());

		require_once TRANSPTHEMEDIR .'include/elements/services.php';
		$elements->register_widget_type(new Elementor\Transp_Services());

		require_once TRANSPTHEMEDIR .'include/elements/pricing.php';
		$elements->register_widget_type(new Elementor\Transp_Pricing());

		require_once TRANSPTHEMEDIR .'include/elements/portfolio.php';
		$elements->register_widget_type(new Elementor\Transp_Portfolio());
		
		require_once TRANSPTHEMEDIR .'include/elements/calculate.php';
		$elements->register_widget_type(new Elementor\Transp_Calculate());

	}

}

if (class_exists('Transp_Elementor_Widgets_Init')){
	Transp_Elementor_Widgets_Init::get_instance();
}

endif;