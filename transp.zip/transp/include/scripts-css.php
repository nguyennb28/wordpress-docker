<?php
/**
 * Enqueue scripts and styles for the front end.
 *
 */
function transp_scripts() {
	// Add Lato font, used in the main stylesheet.
	$fonts_url = transp_fonts_url();
	if ( ! empty( $fonts_url ) ){
		wp_enqueue_style( 'transp-fonts', esc_url_raw( $fonts_url ), array(), null );
	}
	wp_enqueue_style( 'normalize', esc_url(TRANSPTHEMEURI . 'css/normalize.css'), array(), null );
	wp_enqueue_style( 'bootstrap', esc_url(TRANSPTHEMEURI . 'css/bootstrap.min.css'), array(), null );
	wp_enqueue_style( 'owl-carousel', esc_url(TRANSPTHEMEURI . 'css/owl.carousel.min.css'), array(), null );	
	wp_enqueue_style( 'magnific-popup', esc_url(TRANSPTHEMEURI . 'css/magnific-popup.css'), array(), null );
	wp_enqueue_style( 'uicons-regular', esc_url(TRANSPTHEMEURI . 'css/uicons-regular-rounded.css'), array(), null );
	wp_enqueue_style( 'perfect-scrollbar', esc_url(TRANSPTHEMEURI . 'css/perfect-scrollbar.css'), array(), null );
	wp_enqueue_style( 'slick', esc_url(TRANSPTHEMEURI . 'css/slick.css'), array(), null );
	wp_enqueue_style( 'animate', esc_url(TRANSPTHEMEURI . 'css/animate.min.css'), array(), null );
	wp_enqueue_style( 'transp-custom-icon', esc_url(TRANSPTHEMEURI . 'css/custom-icon.css'), array(), null );
	wp_enqueue_style( 'transp-styles', esc_url(TRANSPTHEMEURI . 'css/styles.css'), array(), null );
	wp_enqueue_style( 'transp-responsive', esc_url(TRANSPTHEMEURI . 'css/responsive.css'), array(), null );

	// Load our main stylesheet.
	wp_enqueue_style( 'transp-style', get_stylesheet_uri() );

	//scripts
	/*
	 * Adds JavaScript to pages with the comment form to support
	 * sites with threaded comments (when in use).
	 */
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ){
		wp_enqueue_script( 'comment-reply' );
	}
	wp_enqueue_script( 'bootstrap', esc_url(TRANSPTHEMEURI . 'js/lib/bootstrap.min.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'modernizr', esc_url(TRANSPTHEMEURI . 'js/lib/modernizr.custom.js'), array( 'jquery' ), '', true );
	wp_enqueue_script( 'waypoints', esc_url(TRANSPTHEMEURI . 'js/lib/waypoints.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'wow', esc_url(TRANSPTHEMEURI . 'js/lib/wow.js'), array( 'jquery' ), '', true );
	wp_enqueue_script( 'perfect-scrollbar', esc_url(TRANSPTHEMEURI . 'js/lib/perfect-scrollbar.min.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'scrollup', esc_url(TRANSPTHEMEURI . 'js/lib/scrollup.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'noUISlider', esc_url(TRANSPTHEMEURI . 'js/lib/noUISlider.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'slider', esc_url(TRANSPTHEMEURI . 'js/lib/slider.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'jquery-easing', esc_url(TRANSPTHEMEURI . 'js/lib/jquery.easing.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'jquery-appear', esc_url(TRANSPTHEMEURI . 'js/lib/jquery.appear.js'), array( 'jquery' ), '', true );
	wp_enqueue_script( 'isotope', esc_url(TRANSPTHEMEURI . 'js/lib/isotope.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'owl-carousel', esc_url(TRANSPTHEMEURI . 'js/lib/owl.carousel.min.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'flexslider', esc_url(TRANSPTHEMEURI . 'js/lib/jquery.flexslider.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'materialize', esc_url(TRANSPTHEMEURI . 'js/lib/materialize.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'magnific-popup', esc_url(TRANSPTHEMEURI . 'js/lib/magnific-popup.js'), array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'jquery-fitvid', esc_url(TRANSPTHEMEURI . 'js/lib/jquery.fitvid.js'), array( 'jquery' ), '1.0', true );	
	wp_enqueue_script( 'counterup', esc_url(TRANSPTHEMEURI . 'js/lib/counterup.js'), array( 'jquery' ), '', true );
	wp_enqueue_script( 'countdown', esc_url(TRANSPTHEMEURI . 'js/lib/jquery.countdown.min.js'), array( 'jquery' ), '', true );
	wp_enqueue_script( 'elevatezoom', esc_url(TRANSPTHEMEURI . 'js/lib/jquery.elevatezoom.js'), array( 'jquery' ), '', true );
	wp_enqueue_script( 'slick', esc_url(TRANSPTHEMEURI . 'js/lib/slick.js'), array( 'jquery' ), '', true );		
	wp_enqueue_script( 'transp-scripts', esc_url(TRANSPTHEMEURI . 'js/scripts.js'), array( 'jquery' ), '', true );

	wp_localize_script( 'transp-scripts', 'localize_cost_calculation_data', array('ajax_url' => admin_url('admin-ajax.php')) );
}
add_action( 'wp_enqueue_scripts', 'transp_scripts' );

function transp_styles_custom_banner() {
	
	wp_enqueue_style('transp-custom-banner-style', TRANSPTHEMEURI . 'css/custom_style_banner.css');
	$custom_css = '';
	$banner_image = '';	
	$header_banner_type = get_post_meta(get_the_ID(), 'header_banner_type', true);
	if($header_banner_type == 'custom_image'):
		$banner_image = get_post_meta(get_the_ID(), 'header_custom_image', true);
	endif;
	if($banner_image != ''){
		$custom_css .= ".box-pageheader-1 {
			background-image: url(".esc_url($banner_image).");
		}";    
    }
	
	if(is_singular('give_forms') || is_post_type_archive('give_forms') || is_tax( 'give_forms_category' )):
		$header_banner_type = (function_exists('ot_get_option'))? ot_get_option( 'donation_header_banner_type', 'donation_bg_color' ) : 'donation_bg_color';	
		if($header_banner_type == 'donation_custom_image'):
			$default_banner_image = (function_exists('ot_get_option'))? ot_get_option( 'donation_default_banner_image', TRANSPTHEMEURI. 'images/banner.png' ) : TRANSPTHEMEURI. 'images/banner.png';
			$custom_css .= ".box-pageheader-1 {
				background-image: url(".esc_url($default_banner_image).");
			}";
		else:
			$banner_color = (function_exists('ot_get_option'))? ot_get_option( 'donation_header_custom_color', '#303030' ) : '#303030';
			$custom_css .= ".box-pageheader-1 {
				background-color: ".$banner_color.";
			}";
		endif;
	elseif(is_singular('portfolio') || is_post_type_archive('portfolio')):
		$header_banner_type = (function_exists('ot_get_option'))? ot_get_option( 'portfolio_header_banner_type', 'portfolio_bg_color' ) : 'portfolio_bg_color';	
		if($header_banner_type == 'portfolio_custom_image'):
			$default_banner_image = (function_exists('ot_get_option'))? ot_get_option( 'portfolio_default_banner_image', TRANSPTHEMEURI. 'images/banner.png' ) : TRANSPTHEMEURI. 'images/banner.png';
			$custom_css .= ".box-pageheader-1 {
				background-image: url(".esc_url($default_banner_image).");
			}";
		else:
			$banner_color = (function_exists('ot_get_option'))? ot_get_option( 'portfolio_header_custom_color', '#303030' ) : '#303030';
			$custom_css .= ".box-pageheader-1 {
				background-color: ".$banner_color.";
			}";
		endif;
	elseif(is_page()):
		$header_banner_type = get_post_meta(get_the_ID(), 'header_banner_type', true);
		if($header_banner_type == 'custom_image'):
			$banner_image = get_post_meta(get_the_ID(), 'header_custom_image', true);
			$custom_css .= ".box-pageheader-1 {
				background-image: url(".esc_url($banner_image).");
			}";
		else:
			$banner_color = get_post_meta(get_the_ID(), 'page_header_custom_color', true);
			if($banner_color != ''){
				$custom_css .= ".box-pageheader-1 {
				background-color: ".$banner_color.";
				}";
			} else{
				$custom_css .= ".box-pageheader-1 {
				background-color: #303030;
				}";
			}
					
		endif;
		
		$content_background = get_post_meta(get_the_ID(), 'content_background', true);
			if($content_background != ''){
				$custom_css .= ".section-main-container.section.bgwhite{
				background-color: ".$content_background.";
				}";
			} else{
				$custom_css .= ".section-main-container.section.bgwhite{
				background-color: #ffffff;
				}";
			}
				
	elseif(is_home()):
		$header_banner_type = (function_exists('ot_get_option'))? ot_get_option( 'blog_header_banner_type', 'blog_bg_color' ) : 'blog_bg_color';	
		if($header_banner_type == 'blog_custom_image'):
			$default_banner_image = (function_exists('ot_get_option'))? ot_get_option( 'blog_default_banner_image', TRANSPTHEMEURI. 'images/banner.png' ) : TRANSPTHEMEURI. 'images/banner.png';
			$custom_css .= ".box-pageheader-1 {
				background-image: url(".esc_url($default_banner_image).");
			}";
		else:
			$banner_color = (function_exists('ot_get_option'))? ot_get_option( 'blog_header_custom_color', '#303030' ) : '#303030';
			$custom_css .= ".box-pageheader-1 {
				background-color: ".$banner_color.";
			}";   
    	endif;	
	else:
		$header_banner_type = (function_exists('ot_get_option'))? ot_get_option( 'blog_header_banner_type', 'blog_bg_color' ) : 'blog_bg_color';	
		if($header_banner_type == 'blog_custom_image'):
			$default_banner_image = (function_exists('ot_get_option'))? ot_get_option( 'blog_default_banner_image', TRANSPTHEMEURI. 'images/banner.png' ) : TRANSPTHEMEURI. 'images/banner.png';
			$custom_css .= ".box-pageheader-1 {
				background-image: url(".esc_url($default_banner_image).");
			}";
		else:
			$banner_color = (function_exists('ot_get_option'))? ot_get_option( 'blog_header_custom_color', '#303030' ) : '#303030';
			$custom_css .= ".box-pageheader-1 {
				background-color: ".$banner_color.";
			}";
		endif;
	endif;

	if(class_exists( 'woocommerce' )):
		if( is_product() || is_woocommerce()){
			$header_banner_type = (function_exists('ot_get_option'))? ot_get_option( 'woo_header_banner_type', 'woo_bg_color' ) : 'woo_bg_color';	
			if($header_banner_type == 'woo_custom_image'):
				$default_banner_image = (function_exists('ot_get_option'))? ot_get_option( 'woo_default_banner_image', TRANSPTHEMEURI. 'images/banner.png' ) : TRANSPTHEMEURI. 'images/banner.png';
				$custom_css .= ".box-pageheader-1 {
					background: url(".esc_url($default_banner_image).");
				}";
			else:
				$banner_color = (function_exists('ot_get_option'))? ot_get_option( 'woo_header_custom_color', '#303030' ) : '#303030';
				$custom_css .= ".box-pageheader-1 {
					background-color: ".$banner_color.";
				}";   
			endif;
		}
	endif;
	
	$background_layout = (function_exists('ot_get_option'))? ot_get_option( 'background_layout', 'wide' ) : 'wide';
	if($background_layout == 'boxed'){
		$boxed_background_image = (function_exists('ot_get_option'))? ot_get_option( 'boxed_background_image', TRANSPTHEMEURI.'images/wood_03.jpg' ) : TRANSPTHEMEURI.'images/wood_03.jpg';
		$custom_css .='body.boxed{
			background: url('.esc_url($boxed_background_image).') repeat left center;
		}';
	}
	
	$custom_css .= transp_custom_css_from_theme_options();
    wp_add_inline_style( 'transp-custom-banner-style', $custom_css );

}
add_action( 'wp_enqueue_scripts', 'transp_styles_custom_banner' );


?>