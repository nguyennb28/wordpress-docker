<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Transp_Portfolio extends Widget_Base {


  public $base;

  public function get_style_depends(): array {
	return [ 'swiper', 'e-swiper' ];
    }

    public function get_name() {
        return 'transp-portfolio';
    }

    public function get_title() {
        return esc_html__( 'Portfolios', 'transp' );
    }

    public function get_icon() { 
        return 'eicon-gallery-grid';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
	
		$this->add_control(
			'number_of_posts',
			[
				'label' => esc_html__( 'Number of Portfolios', 'transp' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 48,
				'step' => 1,
				'default' => 6,
			]
		);
		
		$this->add_control(
			'cateogries',
			[
				'label' => esc_html__( 'Select Categories', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => $this->get_portfolios_categories(),
				'label_block' => true,
				'multiple'		=> true,
			]			
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC'  => esc_html__( 'DESC', 'transp' ),
					'ASC' => esc_html__( 'ASC', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'title'  => esc_html__( 'Title', 'transp' ),
					'date' => esc_html__( 'Date', 'transp' ),
					'ID'  => esc_html__( 'ID', 'transp' ),
					'name'  => esc_html__( 'Name', 'transp' ),
					'rand' => esc_html__( 'Rand', 'transp' ),
					'comment_count'  => esc_html__( 'Comment Count', 'transp' ),
					'menu_order' => esc_html__( 'Menu Order', 'transp' ),					
					'author' => esc_html__( 'Author', 'transp' ),
				],
			]
		);	
		
		$this->end_controls_section();

		// posts Style Section //
		
		$this->start_controls_section(
			'posts_style_section',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'posts_color',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masonry-image .h5-lg a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .masonry-image .h5-lg a',
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color Hover', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masonry-image:hover .h5-lg a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cat_color',
			[
				'label' => esc_html__( 'Category Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masonry-image .p-md.grey-color' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'cat_typography',
				'label' => esc_html__( 'Category Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .masonry-image .p-md.grey-color',
			]
		);
       
	  $this->end_controls_section();
		
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		
		$args = array(
		'post_type' 	 => 'jt_portfolio',
		'posts_per_page' => $settings['number_of_posts'],
		'order'          => $settings['order'],
		'orderby'        => $settings['orderby'],
		);
		
		if(!empty($settings['cateogries'])){
			
			$args['tax_query'] = array(
			array(
				'taxonomy' => 'jt_portfolio_category',
				'terms'    => $settings['cateogries'],
				'field'    => 'id',
				),
			);		
		}
		
		$query = get_posts( $args ); ?>
			
		<div class="portfolios-content">			
			<?php if ($query): ?>
				<div class="box-swiper">
					<div class="swiper-container swiper-group-4 pb-50">
						<div class="swiper-wrapper">
							<?php foreach ( $query as $post ): ?>
								<div class="swiper-slide">
									<div class="cardGrid"> 
										<div class="cardImage">
											<?php echo get_the_post_thumbnail( $post->ID, 'full' ); ?>
										</div>
										<div class="cardInfo"> 
											<h5 class="color-brand-2 mb-10">
												<a href="<?php esc_url( the_permalink( $post->ID ) ); ?>">
													<?php echo get_the_title( $post->ID ); ?>
												</a>
											</h5>
											<p class="font-xs color-grey-500"><?php echo get_the_excerpt( $post->ID ); ?></p>
											<div class="box-button mt-30">
												<a class="btn btn-link font-sm color-brand-2"><?php echo esc_html__( 'View Details', 'transp' ); ?>
													<span>
														<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
													</span>
												</a>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>

						<div class="box-pagination-customers text-center wow animate__animated animate__fadeIn">
							<div class="swiper-button-prev swiper-button-prev-style-1 swiper-button-prev-group-4">
								<svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"></path></svg>
							</div>
							<div class="swiper-button-next swiper-button-next-style-1 swiper-button-next-group-4">
								<svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"></path></svg>
							</div>
						</div>

					</div>
				</div>
			<?php endif; ?>     
		</div>
		<?php
    }
	
	public function get_portfolios_categories(){
		$category = [];
		$args = array( 'hide_empty=0' );
		$terms = get_terms( 'jt_portfolio_category', $args );		
		if( !empty( $terms ) ){
			foreach ( $terms as $term ) {
				$category[$term->term_id] = [$term->name];
			}
		}
		return $category;
	}
}