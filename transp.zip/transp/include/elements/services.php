<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Transp_Services extends Widget_Base {


  public $base;

    public function get_name() {
        return 'transp-services';
    }

    public function get_title() {

        return esc_html__( 'Services', 'transp' );

    }

    public function get_icon() { 
        return 'eicon-image-box';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'posts_style',
			[
				'label' => esc_html__( 'Style', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'transp' ),
					'style2' => esc_html__( 'Style 2', 'transp' ),
					'style3' => esc_html__( 'Style 3', 'transp' )
				],
			]
		);
	
		$this->add_control(
			'number_of_posts',
			[
				'label' => esc_html__( 'Number of Posts', 'transp' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 48,
				'step' => 1,
				'default' => 6,
			]
		);

		$this->add_control(
			'number_of_columns',
			[
				'label' => esc_html__( 'Number of Columns', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'3'  => esc_html__( 'Four Columns', 'transp' ),
					'4' => esc_html__( 'Three Columns', 'transp' ),
					'6' => esc_html__( 'Two Columns', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'cateogries',
			[
				'label' => esc_html__( 'Select Categories', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => $this->get_post_categories(),
				'label_block' => true,
				'multiple'		=> true,
			]			
		);

		$this->add_control(
			'select_posts',
			[
				'label' => esc_html__( 'Select Services', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => $this->get_services(),
				'label_block' => true,
				'multiple'		=> true,
			]			
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC'  => esc_html__( 'DESC', 'transp' ),
					'ASC' => esc_html__( 'ASC', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'title'  => esc_html__( 'Title', 'transp' ),
					'date' => esc_html__( 'Date', 'transp' ),
					'ID'  => esc_html__( 'ID', 'transp' ),
					'name'  => esc_html__( 'Name', 'transp' ),
					'rand' => esc_html__( 'Rand', 'transp' ),
					'comment_count'  => esc_html__( 'Comment Count', 'transp' ),
					'menu_order' => esc_html__( 'Menu Order', 'transp' ),					
					'author' => esc_html__( 'Author', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'show_featured_img',
			[
				'label' => esc_html__( 'Show Featured Image', 'transp' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'transp' ),
				'label_off' => esc_html__( 'Hide', 'transp' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'show_read_more_link',
			[
				'label' => esc_html__( 'Show Read More Link', 'transp' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'transp' ),
				'label_off' => esc_html__( 'Hide', 'transp' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => ['posts_style' => ['style1', 'style3']],
			]
		);

		$this->add_control(
			'margin_top',
			[
				'label' => esc_html__( 'Margin Top', 'transp' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'transp' ),
				'label_off' => esc_html__( 'No', 'transp' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => ['posts_style' => ['style2']],
			]
		);		
		
		$this->end_controls_section();

		// Style Section //
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'title_tabs'
		);
		
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-des-title a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop:hover .blog-des-title a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .blog-des-title a',
			]
		);

        $this->add_responsive_control(
			'title_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .blog-des-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Content Style Section //
		
		$this->start_controls_section(
			'style_Content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'content_tabs'
		);
		
		$this->start_controls_tab(
			'content_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .rel-blog-desc p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'content_bg_color',
			[
				'label' => esc_html__( 'Content BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .rel-blog-desc' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'content_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'content_color_hover',
			[
				'label' => esc_html__( 'Content Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .posts-loop:hover .rel-blog-desc p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'content_hover_bg_color',
			[
				'label' => esc_html__( 'Content BG Hover Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .posts-loop:hover .rel-blog-desc' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .posts-content .rel-blog-desc p',
			]
		);

        $this->add_responsive_control(
			'content_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .posts-content .rel-blog-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
		
		$this->add_responsive_control(
			'content_margin',
			[
				'label' =>esc_html__( 'Margin', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .card-offer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
       
      $this->end_controls_section();
	  
	  // Meta Style Section //
		
		$this->start_controls_section(
			'style_meta_section',
			[
				'label' => esc_html__( 'Meta', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'meta_tabs'
		);
		
		$this->start_controls_tab(
			'meta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Meta Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .blog-meta a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_icon_color',
			[
				'label' => esc_html__( 'Meta Icon Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .blog-meta a .svg-inline--fa' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_bg_color',
			[
				'label' => esc_html__( 'Meta BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .blog-meta' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'meta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color_hover',
			[
				'label' => esc_html__( 'Meta Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .posts-loop:hover .blog-meta a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_hove_icon_color',
			[
				'label' => esc_html__( 'Meta Icon Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .posts-loop:hover .blog-meta a .svg-inline--fa' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_hover_bg_color',
			[
				'label' => esc_html__( 'Meta BG Hover Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-content .posts-loop:hover .blog-meta' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .posts-content .blog-meta a',
			]
		);

        $this->add_responsive_control(
			'meta_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .posts-content .blog-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Read More Style Section //
		
		$this->start_controls_section(
			'read_more_section',
			[
				'label' => esc_html__( 'Read More', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'read_more_tabs'
		);
		
		$this->start_controls_tab(
			'read_more_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'read_more_color',
			[
				'label' => esc_html__( 'Read More Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop .read-more-link' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'read_more_bg_color',
			[
				'label' => esc_html__( 'Read More BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop .read-more-link' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'read_more_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'readmore_color_hover',
			[
				'label' => esc_html__( 'Read More Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop:hover .read-more-link' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'read_more_hover_bg_color',
			[
				'label' => esc_html__( 'Read More Hover BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop:hover .read-more-link' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();

        $this->add_responsive_control(
			'read_more_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .posts-loop .read-more-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Category Style Section //
		
		$this->start_controls_section(
			'category_section',
			[
				'label' => esc_html__( 'Category', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'category_tabs'
		);
		
		$this->start_controls_tab(
			'category_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'category_color',
			[
				'label' => esc_html__( 'Category Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop .cat-readmore-con .text-right a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'category_bg_color',
			[
				'label' => esc_html__( 'Category BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop .cat-readmore-con .text-right a' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'category_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'category_color_hover',
			[
				'label' => esc_html__( 'Category Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop:hover .cat-readmore-con .text-right a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'category_hover_bg_color',
			[
				'label' => esc_html__( 'Category Hover BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .posts-loop:hover .cat-readmore-con .text-right a' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'category_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .posts-loop .cat-readmore-con .text-right a',
			]
		);

        $this->add_responsive_control(
			'category_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .posts-loop .cat-readmore-con .text-right a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
	  
	  $this->add_responsive_control(
			'category_borderradius',
			[
				'label' =>esc_html__( 'Border Radius', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .posts-loop .cat-readmore-con .text-right a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
		
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		
		$args = array(
		'posts_per_page' => $settings['number_of_posts'],
		'order'          => $settings['order'],
		'orderby'        => $settings['orderby'],
		'post_type'		 => 'jt_service'
		);
		
		if( ! empty( $settings['cateogries'] ) ) {
			
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'jt_service_category',
					'terms'    => $settings['cateogries'],
					'field' => 'id'
				)
			);		
		}
		
		if( ! empty( $settings['select_posts'] ) ) {			
			$args['post__in'] = $settings['select_posts'];		
		} 
		
		$query = get_posts( $args );

		$cloumns = $settings['number_of_columns'];
		$margin_top = '';
		?>
        
		<div class="posts-content">
			<?php if( $settings['posts_style'] == 'style3' ): ?>
				<?php if ( $query ): ?>
					<?php foreach ( $query as $key => $post ): ?>
						<div class="single-service">

							<?php if(has_post_thumbnail($post->ID) && $settings['show_featured_img'] == 'yes'): ?>
								<a href="<?php esc_url(the_permalink($post->ID)); ?>">
									<?php echo get_the_post_thumbnail( $post->ID, array( 200, 200) ); ?>
								</a>
							<?php endif; ?>

							<h3 class="color-brand-2 mb-15 wow animate__animated animate__fadeIn">
								<a href="<?php esc_url(the_permalink($post->ID)); ?>">
									<?php echo get_the_title($post->ID); ?>
								</a>
							</h3>

							<p class="font-md color-grey-700 wow animate__animated animate__fadeIn"><?php echo get_the_excerpt( $post->ID ); ?></p>
						
							<?php if( $settings['show_read_more_link'] == 'yes' ): ?>
								<div class="mt-20 wow animate__animated animate__fadeIn">
									<a class="btn btn-link font-sm color-brand-2" href="<?php esc_url(the_permalink($post->ID)); ?>"><?php echo esc_html__( 'View Details', 'transp' ); ?>
										<span>
											<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
											</svg>
										</span>
									</a>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
			<?php elseif( $settings['posts_style'] == 'style2' ): ?>
            	<?php if ( $query ): ?>
                <div class="row low-padding justify-content-center">
                    <?php foreach ( $query as $key => $post ):
					if( $settings['margin_top'] == 'yes' ) {
						if( $key % 2 == 1 ) {
							$margin_top = ' mt-30';
						} else {
							$margin_top = '';
						}
					}						
					?>
                    <div class="col-md-6 col-lg-<?php echo esc_attr( $cloumns ); ?> posts-style2">
						<div class="item-reason wow animate__animated animate__fadeIn<?php echo esc_attr( $margin_top ); ?>">
							<div class="card-offer cardServiceStyle3 hover-up">
								<?php if(has_post_thumbnail($post->ID) && $settings['show_featured_img'] == 'yes'): ?>
								<div class="card-image">
									<a href="<?php esc_url(the_permalink($post->ID)); ?>">
										<?php echo get_the_post_thumbnail( $post->ID, array( 200, 200) ); ?>
									</a>
								</div>
								<?php endif; ?>
								<div class="card-info">
									<h5 class="color-brand-2 mb-15">
										<a href="<?php esc_url(the_permalink($post->ID)); ?>"><?php echo get_the_title($post->ID); ?></a>
									</h5>
									<p class="font-sm color-grey-900"><?php echo wp_trim_words( get_the_excerpt( $post->ID ), 12, '' ); ?></p>
								</div>
							</div>
						</div>               
                    </div>
                    <?php
					endforeach;
					?>
                </div>
                <?php endif; ?>            	
            <?php else: ?>
				<?php
				if ($query): ?>
					<div class="row justify-content-center">
						<?php foreach ( $query as $post ): ?>
							<div class="col-lg-<?php echo esc_attr( $cloumns ); ?> col-md-6 wow animate__animated animate__fadeIn">
								<div class="card-offer hover-up">
									<?php if(has_post_thumbnail($post->ID) && $settings['show_featured_img'] == 'yes'): ?>
									<div class="card-image">
										<a href="<?php esc_url(the_permalink($post->ID)); ?>">
											<?php echo get_the_post_thumbnail( $post->ID, array( 200, 200) ); ?>
										</a>
									</div>
									<?php endif; ?>

									<div class="card-info">
										<h5 class="color-brand-2 mb-15"><a href="<?php esc_url(the_permalink($post->ID)); ?>"><?php echo get_the_title($post->ID); ?></a></h5>
										<p class="font-sm color-grey-900 mb-35"><?php echo get_the_excerpt( $post->ID ); ?></p>
										<?php if( $settings['show_read_more_link'] == 'yes' ): ?>
											<div class="box-button-offer mb-30">
												<a class="btn btn-link font-sm color-brand-2" href="<?php esc_url(the_permalink($post->ID)); ?>"><?php echo esc_html__( 'View Details', 'transp' ); ?>
													<span>
														<svg class="w-6 h-6 icon-16" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
														<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
														</svg>
													</span>
												</a>
											</div>
										<?php endif; ?>
									</div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
                <?php endif; ?>
            <?php endif; ?>       
		</div>
    	<?php  
    }
	
	public function get_post_categories(){
		$args = array( 'hide_empty=0' );
		$terms = get_terms( 'jt_service_category', $args );
		$category = [];
		foreach ( $terms as $term ) {
			$category[ $term->term_id ] = [ $term->name ];
		}

		return $category;
	}

	public function get_services() {

		$args = [
			'posts_per_page' => -1,
			'post_type'		 => 'jt_service'
		];

		$query = get_posts( $args );
		$services = [];
		foreach ( $query as $service ) {
			$services[ $service->ID ] = [ get_the_title( $service->ID ) ];
		}

		return $services;
	}

}