<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class Transp_Slider extends Widget_Base {


  public $base;

    public function get_name() {
        return 'transp-slider';
    }

    public function get_title() {

        return esc_html__( 'Slider', 'transp' );

    }

    public function get_icon() { 
        return 'eicon-image-rollover';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'sliders_image',
			[
				'label' => esc_html__( 'Slider Image', 'transp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
        
        $repeater->add_control(
			'slider_title',
			[
				'label' => esc_html__( 'Slider Title', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'TRANSP IS CERTIFIED
				CLEANING COMPANY', 'transp' ),
				'placeholder' => esc_html__( 'Type your title here', 'transp' ),
			]
        );

        $repeater->add_control(
			'slider_description',
			[
				'label' => esc_html__( 'Slider Description', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum sed massa quis ullamcorper. Donec at scelerisque.', 'transp' ),
				'placeholder' => esc_html__( 'Type slider description', 'transp' ),
			]
		);

		$repeater->add_control(
			'read_more_text',
			[
				'label' => esc_html__( 'Button Text', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Request Quote', 'transp' ),
				'placeholder' => esc_html__( 'Type button text here', 'transp' ),
			]
        );
		
		$repeater->add_control(
			'read_more_link',
			[
				'label' => esc_html__( 'Button Link', 'transp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://', 'transp' ),
				'show_external' => false,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => true,
				],
			]
		);

		$repeater->add_control(
			'slider_video_link',
			[
				'label' => esc_html__( 'Video Link', 'transp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://', 'transp' ),
				'show_external' => false,
			]
		);

		$repeater->add_control(
			'select_column',
			[
				'label' => esc_html__( 'Box Align', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '7',
				'options' => [
					'left'  => esc_html__( 'Left', 'transp' ),
					'center'  => esc_html__( 'Center', 'transp' ),
					'right' => esc_html__( 'Right', 'transp' ),
				],
			]
		);

		$repeater->add_control(
			'slide_text_align',
			[
				'label' => esc_html__( 'Text Align', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'center',
				'options' => [
					'center'  => esc_html__( 'Center', 'transp' ),
					'left' => esc_html__( 'Left', 'transp' ),
					'right' => esc_html__( 'Right', 'transp' ),
				],
			]
		);

		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'slide_font_size_rep',
				'label' => esc_html__( 'Title Typography', 'transp' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .caption-txt .title h2',
			]
		);
		
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Slider List', 'transp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'sliders_image' => esc_html__( 'Slider Image', 'transp' ),
						'slider_title' => esc_html__( 'TRANSP IS CERTIFIED
						CLEANING COMPANY', 'transp' ),
						'slider_description' => esc_html__( 'Quisque suscipit ipsum est, eu venenatis leo ornare eget. Ut porta facilisis elementum. Sed condimentum sed massa quis ullamcorper. Donec at scelerisque.', 'transp' ),
						'read_more_text' => esc_html__( 'Request Quote', 'transp' ),
						'read_more_link' => esc_html__( 'https://', 'transp' ),
						'slider_video_link' => esc_html__( '#', 'transp' ),
						'select_column' => esc_html__( 'left', 'transp' ),
						'slide_text_align' => esc_html__( 'left', 'transp' ),
						'slide_font_size_rep' => ''
					],
				],
				'title_field' => '{{{ slider_title }}}',
			]
		);
 

        $this->add_responsive_control(
			'padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .testimonials-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Style Section //
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides h2' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .slider .slides h2',
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .slider .slides h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();

	  $this->start_controls_section(
		'des_style_section',
		[
			'label' => esc_html__( 'Description', 'transp' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
			'des_color',
			[
				'label' => esc_html__( 'Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'des_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .slider .slides p',
			]
		);

		$this->add_responsive_control(
			'des_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .slider .slides p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );

	  $this->end_controls_section();

	  $this->start_controls_section(
		'btn_style_section',
		[
			'label' => esc_html__( 'Button', 'transp' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
		);
		
		$this->start_controls_tabs(
			'btn_tabs'
		);
		
		$this->start_controls_tab(
			'btn_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);		
		
		$this->add_control(
			'btn_color',
			[
				'label' => esc_html__( 'Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides .btn.btn-primary' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'btn_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides .btn.btn-primary' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'btn_border_color',
			[
				'label' => esc_html__( 'Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides .btn.btn-primary' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'btn_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'btn_color_hover',
			[
				'label' => esc_html__( 'Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides .btn.btn-primary:hover, {{WRAPPER}} .slider .slides .btn.btn-primary:focus' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'icon_hover_bg_color',
			[
				'label' => esc_html__( 'Hover BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides .btn.btn-primary:hover, {{WRAPPER}} .slider .slides .btn.btn-primary:focus' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'btn_border_hover_color',
			[
				'label' => esc_html__( 'Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .slides .btn.btn-primary:hover, {{WRAPPER}} .slider .slides .btn.btn-primary:focus' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .slider .slides .btn.btn-primary',
			]
		);	

        $this->add_responsive_control(
			'btn_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .slider .slides .btn.btn-primary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  $this->start_controls_section(
			'style_control_section',
			[
				'label' => esc_html__( 'Controls', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'bgcontrol_tabs'
		);
		
		$this->start_controls_tab(
			'bgcontrol_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'bgcontrol_color',
			[
				'label' => esc_html__( 'Dots Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .indicators .indicator-item' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'bgcontrol_hover_tab',
			[
				'label' => esc_html__( 'Active', 'transp' ),
			]
		);
		
		$this->add_control(
			'bgcontrol_color_hover',
			[
				'label' => esc_html__( 'Dots Active Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .indicators .indicator-item.active' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
       
	  $this->end_controls_section();
	  
	  // End Style Section //
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		
        if ( $settings['list'] ):		
		?>
		<div class="main-slider-content">
			<div class="slider">
			    <ul class="slides">
					<?php
					$i = 1;
					foreach (  $settings['list']  as $index => $item ): ?>
						<?php
						$link_key = 'link_' . $index;
						$this->add_render_attribute( $link_key, 'class', [
							'elementor-repeater-item-' . $item['_id'],
						] );
						?>
						<li id="slide-<?php echo esc_attr($i); ?>" <?php $this->print_render_attribute_string( $link_key ); ?>>
							<!-- Background Image -->
							<?php if($item['sliders_image']['url'] != ''): ?>
							<img src="<?php echo esc_url($item['sliders_image']['url']); ?>" alt="<?php echo esc_attr($item['slider_title']); ?>" />
							<?php endif; ?>

							<?php if($item['select_column'] == 'right'){
								$class_col = 'col-md-6 offset-md-6';
							}elseif($item['slide_text_align'] == 'center'){
								$class_col = 'col-md-8 offset-md-2';
							} else{
								$class_col = 'col-md-6';	
							}
							?>

							<!-- Image Caption -->
							<div class="caption d-flex align-items-center text-<?php echo esc_attr($item['slide_text_align']); ?>">
								<div class="container">
									<div class="row">
										<div class="<?php echo esc_attr($class_col); ?>">    
											<div class="caption-txt">
												<!-- Title -->
												<?php if($item['slider_title'] != ''): ?>
													<div class="title"><h2><?php echo esc_html($item['slider_title']); ?></h2></div>
												<?php endif; ?>

												<!-- Text -->
												<?php if($item['slider_description'] != ''): ?>
													<p><?php echo wp_kses($item['slider_description'], array('span'=>array('class'=>array()))); ?></p>
												<?php endif; ?>

												<?php
												$target = $item['read_more_link']['is_external'] ? ' target="_blank"' : '';
												$nofollow = $item['read_more_link']['nofollow'] ? ' rel="nofollow"' : '';
												if($item['read_more_text'] != ''): ?>
													<a class="btn btn-primary" href="<?php echo esc_url($item['read_more_link']['url']); ?>" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>><?php echo esc_html($item['read_more_text']); ?> <i class="cs-icon cs-195-right-arrow-1"></i></a>
												<?php endif; ?>
												<?php
												$video_url = $item['slider_video_link']['url'];
												$target = $item['slider_video_link']['is_external'] ? ' target="_blank"' : '';
												$nofollow = $item['slider_video_link']['nofollow'] ? ' rel="nofollow"' : '';			
												if( $video_url != '' ):
													?>
													<a href="<?php echo esc_url($video_url); ?>" data-url="<?php echo esc_url($video_url); ?>" class="video-popup"<?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>>
													<i class="fas fa-play"></i></a>
													<?php											
												endif;
												?>
											</div>
										</div>
									</div>  <!-- End row -->
								</div>  <!-- End container -->
							</div>	<!-- End Image Caption -->
						</li>	<!-- END SLIDE #1 -->
						<?php $i++; ?>	
					<?php endforeach; ?>
				</ul> 
			</div>
		</div>
		<?php endif; ?>
        <?php
	}

    protected function content_template() {}
}