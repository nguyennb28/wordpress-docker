<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class Transp_Title extends Widget_Base {


  public $base;

    public function get_name() {
        return 'transp-title';
    }

    public function get_title() {

        return esc_html__( 'Title', 'transp'  );

    }

    public function get_icon() { 
        return 'eicon-t-letter';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Style', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'transp' ),
					'style2' => esc_html__( 'Style 2', 'transp' ),
				],
			]
		);
	
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Discover powerful features to boost your productivity', 'transp' ),
				'placeholder' => esc_html__( 'Type your title here', 'transp' ),
			]
		);
		
		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
				'placeholder' => esc_html__( 'Type your sub-title here', 'transp' ),
			]
		);

		$this->add_control(
			'listicon',
			[
				'label' => esc_html__( 'Icon', 'transp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => '',
					'library' => 'solid',
				],
			]
		);
		
		$this->add_control(
			'description',
			[
				'label' => esc_html__( 'Description', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => 'Aliquam a augue suscipit luctus neque purus ipsum neque dolor primis a libero tempus blandit and cursus varius and magnis sapien',
				'placeholder' => esc_html__( 'Type your description here', 'transp' ),
			]
		);
		
		$this->add_responsive_control(
            'text_align', [
                'label'          => esc_html__( 'Alignment', 'transp'  ),
                'type'           => Controls_Manager::CHOOSE,
                'options'        => [
    
                    'left'         => [
                        'title'    => esc_html__( 'Left', 'transp'  ),
                        'icon'     => 'fas fa-align-left',
                    ],
                    'center'     => [
                        'title'    => esc_html__( 'Center', 'transp'  ),
                        'icon'     => 'fas fa-align-center',
                    ],
                    'right'         => [
                        'title'     => esc_html__( 'Right', 'transp'  ),
                        'icon'     => 'fas fa-align-right',
                    ],
                ],
               'default'         => 'center',
               'selectors' => [
                   '{{WRAPPER}} .heading-content' => 'text-align: {{VALUE}};'
               ],
            ] 
		);
		
		$this->add_responsive_control(
			'main_margin',
			[
				'label' =>esc_html__( 'Margin', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .heading-content, {{WRAPPER}} .heading-content .heading-style-two' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      	);
		
		$this->end_controls_section();

		// Style Section //
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'title_tabs'
		);
		
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content h2' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content:hover h2' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .heading-content h2',
			]
		);

        $this->add_responsive_control(
			'title_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .heading-content h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      	);
       
      	$this->end_controls_section();
	  
	  	$this->start_controls_section(
			'style_sub_section',
			[
				'label' => esc_html__( 'Sub Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'subtitle_tabs'
		);
		
		$this->start_controls_tab(
			'subtitle_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content .sub-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'subtitle_bg_color',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content .sub-title' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'subtitle_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'subtitle_color_hover',
			[
				'label' => esc_html__( 'Sub Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content:hover .sub-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'subtitle_bg_color_hover',
			[
				'label' => esc_html__( 'Sub Title BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content:hover .sub-title' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .heading-content .sub-title',
			]
		);

        $this->add_responsive_control(
			'sub_title_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .heading-content .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      	);

	  $this->add_responsive_control(
		'sub_title_border_radius',
		[
			'label' =>esc_html__( 'Border Radius', 'transp'  ),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', 'em', '%' ],
			'selectors' => [
				'{{WRAPPER}} .heading-content .sub-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
  	   );
       
	  $this->end_controls_section();
	  
	  // Description Section //
		
		$this->start_controls_section(
			'description_section',
			[
				'label' => esc_html__( 'Description', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'description_tabs'
		);
		
		$this->start_controls_tab(
			'description_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'description_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'description_color_hover',
			[
				'label' => esc_html__( 'description Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading-content:hover p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .heading-content p',
			]
		);

        $this->add_responsive_control(
			'description_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .heading-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();

	  
	  // End Style Section //
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		?>
        
		<div class="heading-content <?php echo esc_attr($settings['text_align']); ?>">
			<?php if($settings['title_style'] == 'style2'): ?>
				<?php if($settings['title'] != ''): ?>
					<h2 class="heading-style-two"><?php echo esc_html($settings['title']); ?></h2>
				<?php endif; ?>
            <?php else: ?>
				<?php if($settings['listicon'] != ''): ?>
					<div class="heading-icon"><?php \Elementor\Icons_Manager::render_icon( $settings['listicon']); ?></div>
				<?php endif; ?>
				
				<div class="row">	
					<div class="col-lg-10 offset-lg-1">
						<div class="section-title mb-40 text-center">	

							<?php if($settings['sub_title'] != ''): ?>
								<h2 class="tra-header txt-color-02">
									<?php echo esc_html($settings['sub_title']); ?>
								</h2>
							<?php endif; ?>
							<?php if($settings['title'] != ''): ?>
								<h3 class="h3-xl txt-color-01"><?php echo esc_html($settings['title']); ?></h3>
							<?php endif; ?>
							<?php if($settings['description'] != ''): ?>
								<p class="p-lg txt-color-05"><?php echo wp_kses($settings['description'], array('p'=>array())); ?></p>
							<?php endif; ?>
								
						</div>	
					</div>
				</div>
            <?php endif; ?>       
		</div>
    	<?php  
    }
    protected function content_template() {}
}