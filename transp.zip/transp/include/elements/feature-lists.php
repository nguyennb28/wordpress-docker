<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class Transp_Feature_Lists extends Widget_Base {


  public $base;

    public function get_name() {
        return 'transp-feature-lists';
    }

    public function get_title() {

        return esc_html__( 'Feature Lists', 'transp'  );

    }

    public function get_icon() { 
        return 'eicon-post-list';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
		
		$repeater = new \Elementor\Repeater();
	
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Feature 1', 'transp' ),
				'placeholder' => esc_html__( 'Type your feature title here', 'transp' ),
				'label_block' => true,
			]
        );
		
		$repeater->add_control(
			'read_more_link',
			[
				'label' => esc_html__( 'More Link', 'transp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://', 'transp' ),
				'show_external' => false,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => true,
				],
			]
		);

		$repeater->add_control(
			'title_text_color',
			[
				'label' => esc_html__( 'Title Text Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .h5-sm.txt-color-01' => 'color: {{VALUE}}',
				],
			]
		);

		$repeater->add_control(
			'box_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .abox-4' => 'background-color: {{VALUE}}',
				],
			]
		);

		$repeater->add_control(
			'box_percentage_color',
			[
				'label' => esc_html__( 'Percentage Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .txt-color-04' => 'color: {{VALUE}}',
				],
			]
		);

		$repeater->add_control(
			'percent',
			[
				'label' => esc_html__( 'Percent', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '-25%', 'transp' ),
				'placeholder' => esc_html__( 'Type your percent here', 'transp' ),
				'label_block' => true,
			]
        );
		
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Feature List', 'transp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => esc_html__( 'Title #1', 'transp' ),
						'percent' => esc_html__( '-25%', 'transp' ),
						'read_more_link' => esc_html__( '#', 'transp' ),
						'title_text_color' => '#303030',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_control(
			'number_of_column',
			[
				'label' => esc_html__( 'Number of Column', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'6'  => esc_html__( '2 Columns', 'transp' ),
					'4' => esc_html__( '3 Columns', 'transp' ),
					'3'  => esc_html__( '4 Columns', 'transp' ),
				],
			]
		);
		
		$this->add_responsive_control(
			'feature_margin',
			[
				'label' =>esc_html__( 'Margin', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .advantages' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
            'text_align', [
                'label'          => esc_html__( 'Alignment', 'transp'  ),
                'type'           => Controls_Manager::CHOOSE,
                'options'        => [
    
                    'left'         => [
                        'title'    => esc_html__( 'Left', 'transp'  ),
                        'icon'     => 'fas fa-align-left',
                    ],
                    'center'     => [
                        'title'    => esc_html__( 'Center', 'transp'  ),
                        'icon'     => 'fas fa-align-center',
                    ],
                    'right'         => [
                        'title'     => esc_html__( 'Right', 'transp'  ),
                        'icon'     => 'fas fa-align-right',
                    ],
                ],
               'default'         => '',
               'selectors' => [
                   '{{WRAPPER}} .advantages' => 'text-align: {{VALUE}};'
               ],
            ]
        );
       
        $this->end_controls_section();
		
		// Icon Style Section //
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_text_color',
			[
				'label' => esc_html__( 'Title Text Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .h5-sm.txt-color-01' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .advantages li p',
			]
		);
		
		$this->add_control(
			'percent_color',
			[
				'label' => esc_html__( 'Percent Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .txt-color-04' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'bg_color',
			[
				'label' => esc_html__( 'BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .abox-4' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_font_size',
			[
				'label' => esc_html__( 'Icon Font Size', 'transp' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .advantages li p i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_padding',
			[
				'label' =>esc_html__( 'Icon Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .advantages li p i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_border_color',
			[
				'label' => esc_html__( 'Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .advantages li:after' => 'color: {{VALUE}}',
				],
			]
		);
       
	  $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		if ( $settings['list'] ):
		?>
        <div class="row d-flex align-items-center text-center">         
			<?php foreach (  $settings['list'] as $index => $item ): 
				$link_key = 'link_' . $index;

				$this->add_render_attribute( $link_key, 'class', [
					'col-md-'.$settings['number_of_column'],
					'elementor-repeater-item-' . $item['_id'],
				] );
				
				?>
				<div <?php $this->print_render_attribute_string( $link_key ); ?>>
					<a href="<?php echo esc_url($item['read_more_link']['url']); ?>">
						<div class="abox-4">
							<div class="abox-4-txt">
								<h5 class="h5-sm txt-color-01"><?php echo esc_html($item['title']); ?></h5>
								<span class="txt-color-04"><?php echo esc_html($item['percent']); ?></span>
							</div>
						</div>
					</a>
				</div>				
			<?php endforeach; ?> 
			</div> 
        <?php endif; ?>

        <?php
	}

    protected function content_template() {}
}