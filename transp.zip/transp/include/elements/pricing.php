<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Transp_Pricing extends Widget_Base {


  public $base;

    public function get_name() {
        return 'transp-pricing';
    }

    public function get_title() {

        return esc_html__( 'Pricing', 'transp' );

    }

    public function get_icon() { 
        return 'eicon-price-table';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'posts_style',
			[
				'label' => esc_html__( 'Style', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'transp' ),
					'style_2' => esc_html__( 'Style 2', 'transp' ),
				],
			]
		);
	
		$this->add_control(
			'number_of_posts',
			[
				'label' => esc_html__( 'Number of Pricing', 'transp' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 12,
				'step' => 1,
				'default' => 3,
			]
		);

		$this->add_control(
			'number_of_columns',
			[
				'label' => esc_html__( 'Number of Columns', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'3'  => esc_html__( 'Four Columns', 'transp' ),
					'4' => esc_html__( 'Three Columns', 'transp' ),
					'6' => esc_html__( 'Two Columns', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC'  => esc_html__( 'DESC', 'transp' ),
					'ASC' => esc_html__( 'ASC', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'title'  => esc_html__( 'Title', 'transp' ),
					'date' => esc_html__( 'Date', 'transp' ),
					'ID'  => esc_html__( 'ID', 'transp' ),
					'name'  => esc_html__( 'Name', 'transp' ),
					'rand' => esc_html__( 'Rand', 'transp' ),
					'comment_count'  => esc_html__( 'Comment Count', 'transp' ),
					'menu_order' => esc_html__( 'Menu Order', 'transp' ),					
					'author' => esc_html__( 'Author', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'seleceted_pricing_list',
			[
				'label' => esc_html__( 'Select Pricing', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => $this->selected_pricings(),
				'label_block' => true,
				'multiple'		=> true,
			]			
		);

		$this->add_control(
			'show_monthly_yearly_tab',
			[
				'label' => esc_html__( 'Show monthly/yearly Tab', 'transp' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'transp' ),
				'label_off' => esc_html__( 'No', 'transp' ),
				'return_value' => 'yes',
				'default' => 'no'
			]
		);

		$this->add_control(
            'slider_top',
            [
                'label' => esc_html__( 'Tab Position(top)', 'transp' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => -90,
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-box-tab' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		
		
		$this->end_controls_section();

		// Style Section //
		
		$this->start_controls_section(
			'featured_bg_section',
			[
				'label' => esc_html__( 'Featured', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'featured_tabs_con'
		);
		
		$this->start_controls_tab(
			'featured_normal_tab_con',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'featured_color_con',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg',
			[
				'label' => esc_html__( 'Title BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg_button',
			[
				'label' => esc_html__( 'Button Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-footer a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content_bg_border',
			[
				'label' => esc_html__( 'Price Box Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-box' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'featured_hover_tab_con',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'featured_color_hover_con',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header:hover h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg_hov',
			[
				'label' => esc_html__( 'Title BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header:hover h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg_button_hover',
			[
				'label' => esc_html__( 'Button Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-footer a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content_bg_border_hover',
			[
				'label' => esc_html__( 'Price BOx Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-box:hover' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		
		$this->add_control(
			'featured_color_price',
			[
				'label' => esc_html__( 'Price Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-price p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_price_des',
			[
				'label' => esc_html__( 'Price Des Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-desc p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content',
			[
				'label' => esc_html__( 'Content Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-description h4' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content_span',
			[
				'label' => esc_html__( 'Content Span Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-description h4 span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'featured_color_content_bg_sec',
			[
				'label' => esc_html__( 'Price BOx BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-plan.popular' => 'background-color: {{VALUE}}',
				],
			]
		);
	  
	  $this->add_responsive_control(
			'meta_padding_con_color_feature',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .card-plan.popular' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'title_tabs'
		);
		
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_bg_color',
			[
				'label' => esc_html__( 'Title BG Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_color_border',
			[
				'label' => esc_html__( 'Title Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header:hover h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_bg_color_hover',
			[
				'label' => esc_html__( 'Title BG Hover Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header:hover h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_color_border_hover',
			[
				'label' => esc_html__( 'Title Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-box:hover .pricing-header:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .pricing-header h3',
			]
		);

        $this->add_responsive_control(
			'title_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-header h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Style Cause Section //
		
		$this->start_controls_section(
			'cause_section',
			[
				'label' => esc_html__( 'Price', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'cause_color',
			[
				'label' => esc_html__( 'Price Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-price p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Description Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-desc p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'cause_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .pricing-price p',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'des_typography',
				'label' => esc_html__( 'Description Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .pricing-desc p',
			]
		);

        $this->add_responsive_control(
			'cause_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Meta Style Section //
		
		$this->start_controls_section(
			'meta_section',
			[
				'label' => esc_html__( 'Button', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'meta_tabs'
		);
		
		$this->start_controls_tab(
			'meta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button i' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'meta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_hover_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button:hover i' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .pricing-footer .pricing-button',
			]
		);

        $this->add_responsive_control(
			'meta_padding',
			[
				'label' =>esc_html__( 'Padding', 'transp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
	  
	  $this->add_control(
			'meta_content_color',
			[
				'label' => esc_html__( 'Content Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-description .panel-title' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_content_color_span',
			[
				'label' => esc_html__( 'Content Span Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-description .panel-title span' => 'color: {{VALUE}}',
				],
			]
		);
       
      $this->end_controls_section();
	  
	  $this->start_controls_section(
			'content_bg_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'meta_tabs_con'
		);
		
		$this->start_controls_tab(
			'meta_normal_tab_con',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color_con',
			[
				'label' => esc_html__( 'Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-box' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'meta_hover_tab_con',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color_hover_con',
			[
				'label' => esc_html__( 'Border Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-box:hover' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();

		$this->add_control(
			'content_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-plan' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
			'meta_padding_con',
			[
				'label' =>esc_html__( 'Padding', 'transp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
        );
       
      $this->end_controls_section();
		
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		
		$args = array(
		'post_type' 	 => 'jt_pricing',
		'posts_per_page' => $settings['number_of_posts'],
		'order'          => $settings['order'],
		'orderby'        => $settings['orderby'],
		);
		
		if(!empty($settings['seleceted_pricing_list'])){
			$args['post__in'] = $settings['seleceted_pricing_list'];
		}
		
		$query = get_posts( $args );

		$cloumns = $settings['number_of_columns'];

		?>
        
		<div class="pricing-content <?php echo esc_attr( $settings['posts_style'] ); ?>">
			<?php
			if ($query): ?>
				<?php if( $settings['show_monthly_yearly_tab'] == 'yes' ): ?>
					<div class="text-center wow animate__animated animate__fadeIn pricing-box-tab">
						<span class="text-md color-grey-900 text-billed-month"><?php echo esc_html__( 'Bill Monthly', 'transp' ); ?></span>
						<label class="switch ml-20 mr-20">
							<input id="cb_billed_type" type="checkbox" name="billed_type">
							<span class="slider round"></span>
						</label>
						<span class="text-md color-grey-900 text-billed-year"><?php echo esc_html__( 'Bill Annually', 'transp' ); ?></span>
					</div>
				<?php endif; ?>

				<div class="row justify-content-center align-items-center">
					<?php foreach ( $query as $post ): ?>
						<?php 
						$featured = get_post_meta( $post->ID, 'pricing_featured', true );
						$featured_class = ( $featured == 'on' )? ' popular' : '';
						?>
						<div class="col-lg-<?php echo esc_attr( $cloumns ); ?> wow animate__animated animate__fadeIn">
							<div class="card-plan hover-up<?php echo esc_attr( $featured_class ); ?>">
								<h3 class="color-brand-2 title-plan"><?php echo get_the_title( $post->ID ); ?></h3>
								<p class="font-md color-grey-500 desc-plan"><?php echo get_the_excerpt( $post->ID ); ?></p>
								<?php
								$currency = get_post_meta( $post->ID, 'currency', true );
								$pricing_price = get_post_meta( $post->ID, 'pricing_price', true );
								$pricing_price_year = get_post_meta( $post->ID, 'pricing_price_year', true );
								$period = get_post_meta( $post->ID, 'period', true );
								$period_yearly = get_post_meta( $post->ID, 'period_yearly', true );
								?>
								<div class="item-price-plan"> 
									<div class="for-month display-month">
										<h3 class="color-brand-2 d-inline-block"><?php echo esc_html( $currency ); ?><span><?php echo esc_html( $pricing_price ); ?></span></h3><span class="color-grey-500 font-sm"><?php echo esc_html( $period ); ?></span>
									</div>
									<div class="for-year">
										<h3 class="color-brand-2 d-inline-block"><?php echo esc_html( $currency ); ?><span><?php echo esc_html( $pricing_price_year ); ?></span></h3><span class="color-grey-500 font-sm"><?php echo esc_html( $period_yearly ); ?></span>
									</div>
								</div>

								<div class="line-border"></div>

								<div class="mt-30 mb-30">
									<?php 
									$feature_info = get_post_meta( $post->ID, 'feature_info', true );
									if( !empty( $feature_info ) ): ?>
										<ul class="list-ticks list-ticks-2">
											<?php foreach( $feature_info as $value ): ?>						
												<li>
													<i class="<?php echo esc_html( $value['select_icon'] ); ?>"></i><?php echo esc_html( $value['title'] ); ?>
												</li>
											<?php endforeach; ?>
										</ul>
									<?php endif; ?>                  		
								</div>

								<?php 
								$button_link = get_post_meta( $post->ID, 'button_link', true );
								$button_text = get_post_meta( $post->ID, 'button_text', true );
								?>
								<?php if( $button_link != '' && $button_text != '' ): ?>
									<div class="mt-20">
										<a class="btn btn-brand-2-full hover-up" href="<?php echo esc_url( $button_link ); ?>">
											<?php echo esc_html( $button_text ); ?>
											<svg class="w-6 h-6 icon-16 ml-10" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
										</a>
									</div>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
            <?php endif; ?>       
		</div>
    	<?php
    }
	
	public function selected_pricings(){
		$list = [];
		$args = array(
		'post_type' => 'jt_pricing',
		'posts_per_page' => -1,
		);
		$posts = get_posts( $args );		
		if( !empty( $posts ) ){
			foreach ( $posts as $post ) {
				$list[$post->ID] = [get_the_title($post->ID)];
			}
		}
		return $list;
	}
	
}