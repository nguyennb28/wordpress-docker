<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Transp_Calculate extends Widget_Base {


  public $base;

    public function get_name() {
        return 'transp-calculate';
    }

    public function get_title() {
        return esc_html__( 'Calculate Cost', 'transp' );
    }

    public function get_icon() { 
        return 'eicon-price-table';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'posts_style',
			[
				'label' => esc_html__( 'Style', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'transp' ),
					'style_2' => esc_html__( 'Style 2', 'transp' ),
				],
			]
		);

		$this->add_control(
			'number_of_posts',
			[
				'label' => esc_html__( 'Number of Quantity', 'transp' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 1000,
				'step' => 1,
				'default' => 4,
			]
		);

		$this->add_control(
			'show_contact_button',
			[
				'label' => esc_html__( 'Show Contact Button', 'transp' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'transp' ),
				'label_off' => esc_html__( 'Hide', 'transp' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'read_more_text',
			[
				'label' => esc_html__( 'Contact Button Text', 'transp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Contact Us', 'transp' ),
				'placeholder' => esc_html__( 'Type contact us text here', 'transp' ),
				'condition' => ['show_contact_button' => ['yes']],
			]
        );
		
		$this->add_control(
			'read_more_link',
			[
				'label' => esc_html__( 'Contact Us Link', 'transp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://', 'transp' ),
				'condition' => ['show_contact_button' => ['yes']],
				'show_external' => false,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => true,
				],
			]
		);
		
		$this->end_controls_section();

		// posts Style Section //
		
		$this->start_controls_section(
			'posts_style_section',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'posts_color',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masonry-image .h5-lg a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .masonry-image .h5-lg a',
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color Hover', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masonry-image:hover .h5-lg a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cat_color',
			[
				'label' => esc_html__( 'Category Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masonry-image .p-md.grey-color' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'cat_typography',
				'label' => esc_html__( 'Category Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .masonry-image .p-md.grey-color',
			]
		);
       
	  $this->end_controls_section();
		
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		
		if( function_exists( 'ot_get_option' ) ){
			$calculate_cost = ot_get_option( 'calculate_cost', array() );
			$calculate_dimention = ot_get_option( 'calculate_dimention', 'on' );
			$calculate_width = ot_get_option( 'calculate_width', 'on' );
			$pickup_delivery_locations = ot_get_option( 'pickup_delivery_locations', array() );
			$pickup_delivery_commodities = ot_get_option( 'pickup_delivery_commodities', array() );
			$add_extra_services = ot_get_option( 'add_extra_services', array() );
			if( !empty( $calculate_cost ) ){
			?>
			
			<div class="calculate-shipping-content calculate-<?php echo esc_attr( $settings[ 'posts_style' ] ); ?>">
				<form class="calculate-shipping-form">
					<div class="row align-items-center">
						<div class="col-lg-6">
							<div class="form-group">
								<select class="form-control" name="service_name" id="service_name">
									<?php foreach ( $calculate_cost as $key => $value ) { ?>
										<?php $opt_value = str_replace(' ', '_', $value['title']). '_' .$key; ?>
										<option value="<?php echo esc_attr( $opt_value ); ?>"><?php echo esc_html( $value['title'] ); ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<?php if( $calculate_dimention == 'on' ): ?>
							<div class="col-lg-3">
								<div class="form-group">
									<input class="form-control" type="text" name="calculate_dimention" id="calculate_dimention" placeholder="<?php echo esc_attr__( 'Dimensions', 'transp' ); ?>">
								</div>
							</div>
						<?php endif; ?>
						<?php if($calculate_width == 'on'): ?>
						<div class="col-lg-3">
							<div class="form-group">
								<input class="form-control" type="text" name="calculate_width" id="calculate_width" placeholder="<?php echo esc_attr__( 'Weight', 'transp' ); ?>">
							</div>
						</div>
						<?php endif; ?>
						<div class="col-lg-6">
							<div class="form-group">
								<select class="form-control" name="pickup_location" id="pickup_location">
									<option value=""><?php echo esc_html__( 'Picked up at', 'transp' ); ?></option>
									<?php foreach ( $pickup_delivery_locations as $key => $value ) { ?>
										<?php $location_name = str_replace(' ', '_', $value['location_name']). '_' .$key; ?>
										<option value="<?php echo esc_attr( $location_name ); ?>"><?php echo esc_html( $value['location_name'] ); ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<select class="form-control" name="delivery_location" id="delivery_location">
									<option value=""><?php echo esc_html__( 'Delivery to', 'transp' ); ?></option>
									<?php foreach ( $pickup_delivery_locations as $key => $value ) { ?>
										<?php $location_name = str_replace(' ', '_', $value['location_name']). '_' .$key; ?>
										<option value="<?php echo esc_attr( $location_name ); ?>"><?php echo esc_html( $value['location_name'] ); ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<select class="form-control" name="commodities" id="commodities">
								<option value=""><?php echo esc_html__( 'Commodities', 'transp' ); ?></option>
								<?php foreach ( $pickup_delivery_commodities as $key => $value ) { ?>
									<?php $commodities_name = str_replace(' ', '_', $value['commodities_name']). '_' .$key; ?>
									<option value="<?php echo esc_attr( $commodities_name ); ?>"><?php echo esc_html( $value['commodities_name'] ); ?></option>
								<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">							
								<select class="form-control" name="number_of_quantity" id="number_of_quantity">
									<option value=""><?php echo esc_html__( 'Quantity of goods', 'transp' ); ?></option>
									<?php for ( $i=1; $i <=$settings['number_of_posts']; $i++ ) { ?>
										<option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $i ); ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<textarea class="form-control" name="calculate_message" id="calculate_message" rows="5" placeholder="<?php echo esc_attr__( 'Message / Note', 'transp' ); ?>"></textarea>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group"><strong class="font-sm-bold color-grey-900"><?php echo esc_html__( 'Extra Services', 'transp' ); ?></strong>
								<div class="row mt-10 box-cb-form">
									<?php $currency = ( class_exists( 'woocommerce' ))? get_woocommerce_currency_symbol() : '$'; ?>
									<?php foreach ( $add_extra_services as $key => $charge ) { ?>
										<div class="col-lg-6 col-md-6">
											<div class="form-group">
												<input name="extra_service[]" id="extra_service_<?php echo esc_attr($key); ?>" class="cd-form" type="checkbox" value="<?php echo esc_attr( $charge['extra_service_price'] ); ?>"><?php echo esc_html( $charge['extra_service_name'] );?> (+<?php echo esc_html($currency); ?><?php echo esc_html( $charge['extra_service_price'] ); ?>)
											</div>
										</div>
									<?php } ?>
								</div>
							</div>
						</div>
						<div class="col-lg-12">
							<button class="btn btn-brand-1-big mr-25 cost_calculation_button" type="submit" id="cost_calculation_button">
								<svg fill="none" stroke="currentColor" stroke-width="1.5" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
								<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 15.75V18m-7.5-6.75h.008v.008H8.25v-.008zm0 2.25h.008v.008H8.25V13.5zm0 2.25h.008v.008H8.25v-.008zm0 2.25h.008v.008H8.25V18zm2.498-6.75h.007v.008h-.007v-.008zm0 2.25h.007v.008h-.007V13.5zm0 2.25h.007v.008h-.007v-.008zm0 2.25h.007v.008h-.007V18zm2.504-6.75h.008v.008h-.008v-.008zm0 2.25h.008v.008h-.008V13.5zm0 2.25h.008v.008h-.008v-.008zm0 2.25h.008v.008h-.008V18zm2.498-6.75h.008v.008h-.008v-.008zm0 2.25h.008v.008h-.008V13.5zM8.25 6h7.5v2.25h-7.5V6zM12 2.25c-1.892 0-3.758.11-5.593.322C5.307 2.7 4.5 3.65 4.5 4.757V19.5a2.25 2.25 0 002.25 2.25h10.5a2.25 2.25 0 002.25-2.25V4.757c0-1.108-.806-2.057-1.907-2.185A48.507 48.507 0 0012 2.25z"></path>
								</svg><?php echo esc_html__( 'Cost Calculation', 'transp' ); ?>
							</button>
							<?php 
							if( $settings['show_contact_button'] == 'yes' ):
								if( $settings['read_more_text'] != '' && $settings['read_more_link']['url'] != '' ): 
									$target = $settings['read_more_link']['is_external'] ? ' target="_blank"' : '';
									$nofollow = $settings['read_more_link']['nofollow'] ? ' rel="nofollow"' : '';
									?>
									<a href="<?php echo esc_url($settings['read_more_link']['url']); ?>" class="btn btn-link-medium" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>><?php echo esc_html($settings['read_more_text']); ?>
									<svg class="w-6 h-6 icon-16 ml-5" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
									</a>
								<?php 
								endif; 
							endif;
							?>

							<div id="cost_calculation_result"></div>

						</div>
					</div>
				</form>    
			</div>
			<?php
			}
		}
    }
	
	public function get_porduct_lists(){
		$products = [];
		$args = array(
		'post_type' => 'product',
		'posts_per_page' => -1,
		);
		$posts = get_posts( $args );		
		if( !empty( $posts ) ){
			foreach ( $posts as $post ) {
				$products[$post->ID] = [get_the_title($post->ID)];
			}
		}
		return $products;
	}
}