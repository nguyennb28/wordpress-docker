<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Transp_Posts extends Widget_Base {


  public $base;

    public function get_name() {
        return 'transp-posts';
    }

    public function get_title() {

        return esc_html__( 'Posts', 'transp'  );

    }

    public function get_icon() { 
        return 'eicon-image-box';
    }

    public function get_categories() {
        return [ 'transp-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
	
		$this->add_control(
			'number_of_posts',
			[
				'label' => esc_html__( 'Number of Posts', 'transp' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 48,
				'step' => 1,
				'default' => 3,
			]
		);
		
		$this->add_control(
			'cateogries',
			[
				'label' => esc_html__( 'Select Categories', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => $this->get_post_categories(),
				'label_block' => true,
				'multiple'		=> true,
			]			
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC'  => esc_html__( 'DESC', 'transp' ),
					'ASC' => esc_html__( 'ASC', 'transp' ),
				],
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'transp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'title'  => esc_html__( 'Title', 'transp' ),
					'date' => esc_html__( 'Date', 'transp' ),
					'ID'  => esc_html__( 'ID', 'transp' ),
					'name'  => esc_html__( 'Name', 'transp' ),
					'rand' => esc_html__( 'Rand', 'transp' ),
					'comment_count'  => esc_html__( 'Comment Count', 'transp' ),
					'menu_order' => esc_html__( 'Menu Order', 'transp' ),					
					'author' => esc_html__( 'Author', 'transp' ),
				],
			]
		);		
		
		$this->end_controls_section();

		// Style Section //
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Title', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'title_tabs'
		);
		
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-txt .h5-md a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-1-post:hover .blog-post-txt .h5-md a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .blog-post-txt .h5-md a',
			]
		);

        $this->add_responsive_control(
			'title_margin',
			[
				'label' =>esc_html__( 'Margin', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .blog-post-txt .h5-md' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Content Style Section //
		
		$this->start_controls_section(
			'style_Content_section',
			[
				'label' => esc_html__( 'Content', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-post-txt .p-lg' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .blog-post-txt .p-lg',
			]
		);

        $this->add_responsive_control(
			'content_margin',
			[
				'label' =>esc_html__( 'Margin', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .blog-post-txt .p-lg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Meta Style Section //
		
		$this->start_controls_section(
			'style_meta_section',
			[
				'label' => esc_html__( 'Meta', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'meta_tabs'
		);
		
		$this->start_controls_tab(
			'meta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Meta Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-meta a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'meta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'meta_color_hover',
			[
				'label' => esc_html__( 'Meta Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-1-post:hover .post-meta a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .post-meta a',
			]
		);

        $this->add_responsive_control(
			'meta_margin',
			[
				'label' =>esc_html__( 'Margin', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .post-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Category Style Section //
		
		$this->start_controls_section(
			'category_section',
			[
				'label' => esc_html__( 'Category', 'transp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'category_tabs'
		);
		
		$this->start_controls_tab(
			'category_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'transp' ),
			]
		);
		
		$this->add_control(
			'category_color',
			[
				'label' => esc_html__( 'Category Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .p-md.post-tag a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'category_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'transp' ),
			]
		);
		
		$this->add_control(
			'category_color_hover',
			[
				'label' => esc_html__( 'Category Color', 'transp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-1-post:hover .p-md.post-tag a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'category_typography',
				'label' => esc_html__( 'Typography', 'transp' ),
				'selector' => '{{WRAPPER}} .p-md.post-tag a',
			]
		);

        $this->add_responsive_control(
			'category_margin',
			[
				'label' =>esc_html__( 'Margin', 'transp'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .p-md.post-tag' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
		
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		
		$args = array(
		'posts_per_page' => $settings['number_of_posts'],
		'order'          => $settings['order'],
		'orderby'        => $settings['orderby'],
		'post__not_in' => get_option( 'sticky_posts' )
		);
		
		if(!empty($settings['cateogries'])){
			
			$args['tax_query'] = array(
            array(
                'taxonomy' => 'category',
                'terms'    => $settings['cateogries'],
                'field' => 'id',
                 ),
               );		
		} 
		
		$query = get_posts( $args );
		?>
        
		<div class="posts-content">
			<?php if ($query): ?>
                <div class="row">
					<?php foreach ( $query as $key => $post ): ?>
						<div class="col-md-6 col-lg-4">
				 			<div class="blog-post">
				 				<?php if(has_post_thumbnail($post->ID)): ?>	
							 	<!-- BLOG POST IMAGE -->
					 			<div class="blog-post-img">
								 	<a href="<?php esc_url(the_permalink($post->ID)); ?>">
										<?php echo get_the_post_thumbnail( $post->ID, 'transp-semimedium' ); ?>
									</a>	
								</div>
								<?php endif; ?>

				 				<!-- BLOG POST TITLE -->
								<div class="blog-post-txt">
									<!-- Post Data -->
									<?php if(!empty(get_the_category($post->ID))):?>
										<span class="txt-color-06"><?php the_category(' ', '', $post->ID); ?></span>
									<?php endif; ?>

									<!-- Post Title -->
									<h5 class="h5-sm txt-color-01">
										<a href="<?php esc_url(the_permalink($post->ID)); ?>"><?php echo wp_trim_words( get_the_title($post->ID), 15, '' ); ?></a>
									</h5>

									<!-- Post Text -->
									<p class="txt-color-05"><?php echo wp_trim_words( get_the_content('', '', $post->ID), 18, '' ); ?>
									</p>

									<!-- Post Author -->
									<?php $author_id = $post->post_author; ?>
									<p class="post-author txt-color-05"><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID', $author_id ) ) ); ?>"><?php echo the_author_meta( 'display_name' , $author_id ); ?></a> - <a href="<?php esc_url(the_permalink($post->ID)); ?>"><?php echo get_the_date(get_option( 'date_format' ), $post->ID); ?></a></p>	

								</div>
							</div>
				 		</div>	<!-- END  BLOG POST #1 -->
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>       
		</div>
    	<?php  
    }
    protected function content_template() {}
	
	public function get_post_categories(){
		$args = array( 'hide_empty=0' );
		$terms = get_terms( 'category', $args );
		$category = [];
		foreach ( $terms as $term ) {
			$category[$term->term_id] = [$term->name];
		}
		return $category;
	}
}