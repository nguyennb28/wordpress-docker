<?php
include(TRANSPTHEMEDIR . '/admin/scripts.php');
include(TRANSPTHEMEDIR . '/admin/page-settings.php');
include(TRANSPTHEMEDIR . '/admin/post-settings.php');
include(TRANSPTHEMEDIR . '/admin/pricing-settings.php');
include(TRANSPTHEMEDIR . '/admin/demo-import.php');

function transp_options_filter($var){
    $var = (is_array($var) && ($var['type'] == 'background') || ($var['type'] == 'upload') || ($var['type'] == 'measurement') || ($var['type'] == 'typography') || ($var['type'] == 'colorpicker') || ($var['type'] == 'colorpicker-opacity'));

     return $var;
}


function transp_custom_css_from_theme_options(){
	$custom_css = '';
	if( function_exists( 'ot_get_option' ) ):
    $settings = transp_theme_options();
    $options = array_filter($settings, "transp_options_filter");
    foreach ($options as $option) :
        if(isset($option['action'])){
            if( $option['type'] == 'background' ){
                $background = ot_get_option( $option['id'] );
                $background = (empty($background)) ? $option['std'] : $background;
                if( !empty($background) ){
                    foreach ($option['action'] as $value) {
                        if($value['selector'] != ''){
                            $custom_css .= $value['selector']. '{ ';
                            foreach( $background as $key => $value ){
                                if($key == 'background-image') $custom_css .= ($value != '')? $key. ': url('.esc_url($value).'); ' : '';
                                else $custom_css .= ($value != '')? $key. ': '.$value.'; ' : '';
                            }
                            $custom_css .= '}';
                        }
                    }
				}
			}
			elseif( $option['type'] == 'upload' ){
                $upload = ot_get_option( $option['id'] );
                $upload = ($upload == '') ? $option['std'] : $upload;
                if( $upload != '' ){
                    foreach ($option['action'] as $value) {
						if($value['property'] == 'cursor'){
							$custom_css .= ($value['selector'] != '')? $value['selector']. '{ '.$value['property'].': url('.esc_url($upload).'), auto; } ' : '';
						} else{
						$custom_css .= ($value['selector'] != '')? $value['selector']. '{ '.$value['property'].': url('.esc_url($upload).'); } ' : '';
						}
                    }
				}
			}
			
            elseif( $option['type'] == 'typography' ){
                $typography = ot_get_option( $option['id'], array() );        
                $typography = empty($typography) ? $option['std'] : $typography;
                if(!empty($typography)) {
                    foreach ($option['action'] as $value) {  
                        if($value['selector'] != ''){
                            $custom_css .= $value['selector']. '{ ';
                            foreach ($typography as $key => $value) {
                                if( $key == 'font-color'){
									$custom_css .= ( $value != '' )? 'color: '.$value.'; ' : '';
								}else{
								$custom_css .= ( $value != '' )? $key. ': '.$value.'; ' : '';
								}
                            }
                            $custom_css .= ' }';
                        }
                    }
         
				}
			}
            elseif( $option[ 'type' ] == 'colorpicker' ){
                $colorpicker = ot_get_option( $option['id'] );    

                $colorpicker = ($colorpicker == '') ? $option['std'] : $colorpicker;

                $rgb = transp_hex2rgb($colorpicker);

                if( $colorpicker != '' ){
                    foreach ($option['action'] as $value) {
                        $colorpicker = isset($value['opacity'])? 'rgba('.$rgb.', '.$value['opacity'].')' : $colorpicker;
                        $custom_css .= ($value['selector'] != '')?$value['selector']. '{ '.$value['property'].': '.$colorpicker .'; } ' : '';
                    }
				}
			}
				elseif( $option[ 'type' ] == 'colorpicker-opacity' ){  
                $colorpicker_opacity = ot_get_option( $option['id'] );  

                $colorpicker_opacity = ($colorpicker_opacity == '') ? $option['std'] : $colorpicker_opacity;

                if( $colorpicker_opacity != '' ){
                    foreach ($option['action'] as $value) {
                        $custom_css .= ($value['selector'] != '')? $value['selector']. '{ '.$value['property'].': '.$colorpicker_opacity .'; } ' : '';
                    }
				}
		    }
            elseif( $option[ 'type' ] == 'measurement' ){ 
                $measurement =  ot_get_option( $option['id'], array() ); 
                $measurement = empty($measurement) ? $option['std'] : $measurement; 
                if( !empty( $measurement ) ) {
                    foreach ($option['action'] as $value) {  
                        if($value['selector'] != ''){
                            $custom_css .= $value['selector']. '{ ';
                            $custom_css .= $value['property'].': '.intval($measurement[0]).$measurement[1] .';';
                            $custom_css .= ' }';
                        }
                    }
				}
			}
        }//if(isset($option['action'])):
    endforeach;
	endif;
	return $custom_css;
}


function transp_hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }
   $rgb = array($r, $g, $b);
   $rgb_color = implode(",", $rgb); // returns the rgb values separated by commas
   return $rgb_color;
}

add_filter( 'ot_google_fonts_api_key', 'transp_ot_google_fonts_api_key' );

function transp_ot_google_fonts_api_key( $key ) {
  return (function_exists('ot_get_option'))? ot_get_option( 'google_api_key', '' ) : '';
}

function transp_filter_ot_list_item_settings( $settings, $id ) {
  if ( 'header_social_icons' === $id ) {
    return array(array(
        'id'          => 'link',
        'label'       => esc_html__( 'Link', 'transp' ),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ),
    array(
        'id'          => 'social_class',
        'label'       => esc_html__( 'Icon Class', 'transp' ),
        'desc'        => esc_html__( 'Ex: fa-facebook-f', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ));
  }

  if ( 'calculate_cost' === $id ) {
    return array(
        array(
            'id'          => 'calculate_country',
            'label'       => esc_html__('Select Pickup Location', 'transp'),
            'desc'        => '',
            'std'         => '',
            'type'        => 'select',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => get_all_pickup_delivery_locations()
        ),
        array(
            'id'          => 'calculate_delivery',
            'label'       => esc_html__('Select Delivery Location', 'transp'),
            'desc'        => '',
            'std'         => '',
            'type'        => 'select',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => get_all_pickup_delivery_locations()
        ),
        array(
            'id'          => 'calculate_commodities',
            'label'       => esc_html__('Select Commodities', 'transp'),
            'desc'        => '',
            'std'         => '',
            'type'        => 'select',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => get_all_commodities()
        ),
        array(
            'id'          => 'max_weight',
            'label'       => esc_html__('Item Max Weight', 'transp'),
            'desc'        => esc_html__('Item max weight', 'transp'),
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => '',
        ),
        array(
            'id'          => 'item_price',
            'label'       => esc_html__('Item Price', 'transp'),
            'desc'        => esc_html__('Price Should be integer value(and currency will be woocommerce currency)', 'transp'),
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => '',
        ),
        array(
            'id'          => 'select_product_to_connect',
            'label'       => esc_html__( 'Select Product to Connect', 'transp' ),
            'desc'        => esc_html__( 'All products will show here', 'transp' ),
            'type'        => 'custom-post-type-select',
            'post_type'   => 'product',
        ),
    );
  }

  if ( 'pickup_delivery_locations' === $id ) {
    return array(array(
        'id'          => 'location_name',
        'label'       => esc_html__( 'Location Name', 'transp' ),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ),
    );
  }

  if ( 'pickup_delivery_commodities' === $id ) {
    return array(array(
        'id'          => 'commodities_name',
        'label'       => esc_html__( 'Commodities Name', 'transp' ),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ),
    );
  }

  if ( 'add_extra_services' === $id ) {
    return array(
        array(
            'id'          => 'extra_service_name',
            'label'       => esc_html__( 'Service Name', 'transp' ),
            'desc'        => '',
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
        ),
        array(
            'id'          => 'extra_service_price',
            'label'       => esc_html__( 'Service Price', 'transp' ),
            'desc'        => '',
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
        ),
    );
  }

  if ( 'team_social_icons' === $id ) {
    return array(array(
        'id'          => 'link',
        'label'       => esc_html__( 'Link', 'transp' ),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ),
    array(
        'id'          => 'social_class',
        'label'       => esc_html__( 'Icon Class', 'transp' ),
        'desc'        => esc_html__( 'Ex: fa-facebook-f', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ));
  }
  
  if ( 'create_sidebar' === $id ) {
    return array(array(
        'id'          => 'desc',
        'label'       => esc_html__( 'Description', 'transp' ),
        'desc'        => esc_html__( '(optional)', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ));
  }
  
  if ( 'feature_info' === $id ) {
    return array(array(
        'id'          => 'select_icon',
        'label'       => esc_html__( 'Set Icon', 'transp' ),
        'desc'        => esc_html__( 'Paste a fontawesome icon class here', 'transp' ),
        'std'         => 'fas fa-check-circle',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ));
  }

  if ( 'feature_lists' === $id ) {
    return array(array(
        'id'          => 'desc',
        'label'       => esc_html__( 'Feature', 'transp' ),
        'desc'        => esc_html__( '(optional)', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
    ));
  }

  return $settings;
}
add_filter( 'ot_list_item_settings', 'transp_filter_ot_list_item_settings', 10, 2 );

function get_all_pickup_delivery_locations(){
    $choices = [];

    if( function_exists( 'ot_get_option' ) ){
        $pickup_delivery_locations = ot_get_option( 'pickup_delivery_locations', array() );
        
        if( !empty( $pickup_delivery_locations ) ){
            foreach ( $pickup_delivery_locations as $choice ) {
                $_choice_value = isset( $choice['location_name'] ) ? str_replace( "'", "\'", $choice['location_name'] ) : '';
				$_choice_label = isset( $choice['location_name'] ) ? str_replace( "'", "\'", $choice['location_name'] ) : '';

                $choices[] = ['value' => $choice['location_name'], 'label' => $choice['location_name']];
            }

        }

    }    

    return $choices;
}

function get_all_commodities(){
    $choices = [];

    if( function_exists( 'ot_get_option' ) ){
        $pickup_delivery_commodities = ot_get_option( 'pickup_delivery_commodities', array() );
        
        if( !empty( $pickup_delivery_commodities ) ){
            foreach ( $pickup_delivery_commodities as $choice ) {
                $_choice_value = isset( $choice['commodities_name'] ) ? str_replace( "'", "\'", $choice['commodities_name'] ) : '';
				$_choice_label = isset( $choice['commodities_name'] ) ? str_replace( "'", "\'", $choice['commodities_name'] ) : '';

                $choices[] = ['value' => $choice['commodities_name'], 'label' => $choice['commodities_name']];
            }

        }

    }    

    return $choices;
}