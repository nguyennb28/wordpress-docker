<?php
/**
 * Initialize the meta boxes. 
 */

add_action( 'admin_init', 'transp_post_meta_boxes' );

function transp_post_meta_boxes() {
  if( function_exists( 'ot_get_option' ) ): 
  $my_meta_box = array(
    'id'        => 'transp_post_meta_box',
    'title'     => esc_html__('Transp Post Settings', 'transp'),
    'desc'      => '',
    'pages'     => array( 'post' ),
    'context'   => 'normal',
    'priority'  => 'high',
    'fields'    => array(
	  array(
        'id'          => 'header_settings',
        'label'       => esc_html__('Content Settings', 'transp'),      
        'type'        => 'tab',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'video_link',
        'label'       => esc_html__('Video Link', 'transp'),
        'desc'        => esc_html__('Only Work for post formate video', 'transp'),
        'std'         => '',
        'type'        => 'text',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
      ),
	  array(
        'id'          => 'audio_link',
        'label'       => esc_html__('Audio Link', 'transp'),
        'desc'        => esc_html__('Only Work for post formate audio', 'transp'),
        'std'         => '',
        'type'        => 'text',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
      ),
	  array(
        'id'          => 'image_gallery',
        'label'       => esc_html__('Gallery', 'transp'),
        'desc'        => esc_html__('Only Work for post formate gallery', 'transp'),
        'std'         => '',
        'type'      => 'gallery',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
      ),
	  array(
        'id'          => 'quote_text',
        'label'       => esc_html__('Quote', 'transp'),
        'desc'        => esc_html__('Only Work for post formate quote', 'transp'),
        'std'         => '',
        'type'        => 'textarea',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
      ),
	  array(
        'id'          => 'quote_text_url',
        'label'       => esc_html__('Quote URL', 'transp'),
        'desc'        => esc_html__('Only Work for post formate quote', 'transp'),
        'std'         => '',
        'type'        => 'text',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
      ),
	  array(
        'id'          => 'quote_cite',
        'label'       => esc_html__('Quote Cite', 'transp'),
        'desc'        => esc_html__('Only Work for post formate quote', 'transp'),
        'std'         => '',
        'type'        => 'text',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
      ),
    )
  );
  
  ot_register_meta_box( $my_meta_box );
  endif;
}
?>