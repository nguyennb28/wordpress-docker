<?php
// Register Style
function transp_admin_styles() {

	wp_register_style( 'transp-adminstyle', TRANSPTHEMEURI. 'admin/assets/css/admin-style.css', false, '1.0.0', 'all' );
	wp_enqueue_style( 'transp-adminstyle' );

}

// Hook into the 'admin_enqueue_scripts' action
add_action( 'admin_enqueue_scripts', 'transp_admin_styles' );