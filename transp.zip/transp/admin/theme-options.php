<?php
//include theme options
include TRANSPTHEMEDIR . '/admin/theme-options/general.php';
include TRANSPTHEMEDIR . '/admin/theme-options/background.php';
include TRANSPTHEMEDIR . '/admin/theme-options/header.php';
include TRANSPTHEMEDIR . '/admin/theme-options/sidebar.php';
include TRANSPTHEMEDIR . '/admin/theme-options/footer.php';
include TRANSPTHEMEDIR . '/admin/theme-options/blog.php';
include TRANSPTHEMEDIR . '/admin/theme-options/calculate_cost.php';
include TRANSPTHEMEDIR . '/admin/theme-options/woocommerce.php';
include TRANSPTHEMEDIR . '/admin/theme-options/portfolio.php';
include TRANSPTHEMEDIR . '/admin/theme-options/typography.php';
include TRANSPTHEMEDIR . '/admin/theme-options/styling.php';
/**
 * Initialize the custom theme options.
 */
add_action( 'admin_init', 'transp_theme_options', 1 );

/**
 * Build the custom settings & update OptionTree.
 */
function transp_theme_options() {
  
  /* OptionTree is not loaded yet */
  if ( ! function_exists( 'ot_settings_id' ) )
    return false;
    
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  //available option functions - return type array()
  $general_options      = transp_general_options();
  $background_options   = transp_background_options();
  $header_options       = transp_header_options();
  $sidebar_options      = transp_sidebar_options();
  $footer_options       = transp_footer_options();
  $blog_options         = transp_blog_options();
  $cost_options         = transp_calculate_cost_options();
  $woocommerce_options  = transp_woocommerce_options();
  $portfolio_options    = transp_portfolio_options();
  $typography_options   = transp_typography_options();
  $styling_options      = transp_styling_options();


  //merge all available options
  $settings = array_merge( $general_options, $background_options, $header_options, $sidebar_options, $footer_options, $blog_options, $cost_options, $woocommerce_options, $portfolio_options, $typography_options, $styling_options );

 

  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
    'sections'        => array( 
      array(
        'id'          => 'general_options',
        'title'       => esc_html__( 'General Options', 'transp' )
      ),
      array(
        'id'          => 'background_options',
        'title'       => esc_html__( 'Background Options', 'transp' )
      ),
     array(
        'id'          => 'header_options',
        'title'       => esc_html__( 'Header Options', 'transp' )
      ),
      array(
        'id'          => 'footer_options',
        'title'       => esc_html__( 'Footer Options', 'transp' )
      ),
      array(
        'id'          => 'sidebar_option',
        'title'       => esc_html__( 'Sidebar Options', 'transp' )
      ),
      array(
        'id'          => 'blog_options',
        'title'       => esc_html__( 'Blog Options', 'transp' )
      ),
      array(
        'id'          => 'calculate_cost_options',
        'title'       => esc_html__( 'Calculate Cost Options', 'transp' )
      ),
      array(
        'id'          => 'woocommerce_options',
        'title'       => esc_html__( 'WooCommerce Options', 'transp' )
      ),
	    array(
        'id'          => 'portfolio_options',
        'title'       => esc_html__( 'Portfolio Options', 'transp' )
      ),
      array(
        'id'          => 'fonts',
        'title'       => esc_html__( 'Typography Options', 'transp' )
      ),
      array(
        'id'          => 'styling_options',
        'title'       => esc_html__( 'Styling Options', 'transp' )
      )	  
    ),
    'settings'        => $settings
  );

  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;

  return $custom_settings[ 'settings' ];
  
}