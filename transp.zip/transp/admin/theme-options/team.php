<?php
function transp_team_options( $options = array() ){
	$options = array(
	array(
        'id'          => 'team_title',
        'label'       => esc_html__( 'Team Header Title', 'transp' ),
        'desc'        => esc_html__( 'Team page header title', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'team_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'team_subtitle',
        'label'       => esc_html__( 'Team Header Sub-Title', 'transp' ),
        'desc'        => esc_html__( 'Team page header sub-title', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'team_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'team_column',
        'label'       => esc_html__( 'Team Column in Archive Page', 'transp' ),
        'desc'        => '',
        'std'         => '3',
        'type'        => 'numeric-slider',
        'section'     => 'team_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '1,4,1',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'team_style',
        'label'       => esc_html__( 'Team Style', 'transp' ),
        'desc'        => esc_html__( 'Select team style', 'transp' ),
        'std'         => 'style1',
        'type'        => 'select',
        'section'     => 'team_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
		  array(
            'value'       => 'style1',
            'label'       => esc_html__( 'Style 1', 'transp' ),
          ),
          array(
            'value'       => 'style2',
            'label'       => esc_html__( 'Style 2', 'transp' ),
          )
        )
      ),
	  array(
        'id'          => 'team_header_banner_type',
        'label'       => esc_html__( 'Header Banner Type', 'transp' ),
        'desc'        => esc_html__( 'Select your header banner type', 'transp' ),
        'std'         => 'team_custom_image',
        'type'        => 'select',
        'section'     => 'team_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'team_bg_color',
            'label'       => esc_html__( 'Background Color', 'transp' ),
          ),
		  array(
            'value'       => 'team_custom_image',
            'label'       => esc_html__( 'Custom Image', 'transp' ),
          )
        )
      ),
	  array(
        'id'          => 'team_header_custom_color',
        'label'       => esc_html__('Select Color', 'transp'),
        'desc'        => '',
        'std'         => '#303030',
        'type'        => 'colorpicker',
		'section'     => 'team_options',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
        'condition'   => 'team_header_banner_type:is(team_bg_color)',
      ),
	  array(
        'id'          => 'team_default_banner_image',
        'label'       => esc_html__( 'Background Image', 'transp' ),
        'desc'        => esc_html__( 'Background image', 'transp' ),
        'std'         => TRANSPTHEMEURI. 'images/banner.png',
        'type'        => 'upload',
        'section'     => 'team_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'team_header_banner_type:is(team_custom_image)',
        'operator'    => 'and'
      )
    );

	return apply_filters( 'transp_team_options', $options );
}  
?>