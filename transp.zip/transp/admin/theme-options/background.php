<?php
function transp_background_options( $options = array() ){
	$options = array(
	  array(
        'id'          => 'background_layout',
        'label'       => esc_html__( 'Background Layout', 'transp' ),
        'desc'        => esc_html__( 'Background Layout', 'transp' ),
        'std'         => 'wide',
        'type'        => 'select',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'wide',
            'label'       => esc_html__( 'Wide', 'transp' ),
          ),
          array(
            'value'       => 'boxed',
            'label'       => esc_html__( 'Boxed', 'transp' ),
          )
        )
      ),
	  array(
        'id'          => 'boxed_background_image',
        'label'       => esc_html__( 'Boxed Background Image', 'transp' ),
        'desc'        => esc_html__( 'Boxed background image', 'transp' ),
        'std'         => TRANSPTHEMEURI.'images/wood_03.jpg',
        'type'        => 'upload',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'background_layout:is(boxed)',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'body_background',
        'label'       => esc_html__( 'Body background', 'transp' ),
        'desc'        => esc_html__( 'Background can be image or color', 'transp' ),
        'std'         => array(),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => 'body'
                    )
            )
      ),
      array(
        'id'          => 'main_container_background',
        'label'       => esc_html__( 'Main container background', 'transp' ),
        'desc'        => esc_html__( 'Background can be image or color', 'transp' ),
        'std'         => array(),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => '.container'
                    )
            )
      ),
	  array(
        'id'          => 'sidebar_background',
        'label'       => esc_html__( 'Sidebar background', 'transp' ),
        'desc'        => esc_html__( 'Sidebar Background', 'transp' ),
        'std'         => array('background-image' => '', 'background-color' => ''),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => '.sidebar'
                    )
            )
      ),
	  array(
        'id'          => 'footer_widget_background',
        'label'       => esc_html__( 'Footer Widget background', 'transp' ),
        'desc'        => esc_html__( 'Footer Widget background', 'transp' ),
        'std'         => array('background-image' => '', 'background-color' => ''),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => '.footer.section'
                    )
            )
      ),
	  array(
        'id'          => 'footer_copyright_background',
        'label'       => esc_html__( 'Footer Copyright background', 'transp' ),
        'desc'        => esc_html__( 'Footer Copyright background', 'transp' ),
        'std'         => array('background-image' => '', 'background-color' => ''),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => '.copyrights'
                    )
            )
      ),    
    );

	return apply_filters( 'transp_background_options', $options );
}  
?>