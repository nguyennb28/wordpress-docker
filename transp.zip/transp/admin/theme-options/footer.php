<?php
function transp_footer_options( $options = array() ){	
	$options = array(
		array(
        'id'          => 'footer_style',
        'label'       => esc_html__( 'Footer Style', 'transp' ),
        'desc'        => esc_html__( 'Select footer style', 'transp' ),
        'std'         => 'style1',
        'type'        => 'select',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
		  array(
            'value'       => 'style1',
            'label'       => esc_html__( 'Style 1', 'transp' ),
          ),
          array(
            'value'       => 'style2',
            'label'       => esc_html__( 'Style 2', 'transp' ),
          )
        )
      ),
      array(
        'id'          => 'footer_widget_top_area',
        'label'       => esc_html__( 'Footer Widget Top Area', 'transp' ),
        'desc'        => '',
        'std'         => 'off',
        'type'        => 'on-off',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'footer_widget_area',
        'label'       => esc_html__( 'Footer Widget Area', 'transp' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'footer_widget_box',
        'label'       => esc_html__( 'Footer Widget Box', 'transp' ),
        'desc'        => '',
        'std'         => '4',
        'type'        => 'numeric-slider',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '1,6,1',
        'class'       => '',
        'condition'   => 'footer_widget_area:not(off)',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'footer_widget_box_column_serial',
        'label'       => esc_html__( 'Footer Widget Column Serial', 'transp' ),
        'desc'        => esc_html__( 'Write column number seperate by comma', 'transp' ),
        'std'         => '3,3,3,3',
        'type'        => 'text',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'footer_widget_area:not(off)',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'copyright_text',
        'label'       => esc_html__( 'Copyright Text', 'transp' ),
        'desc'        => '',
        'std'         => sprintf(esc_html__('%1$s &copy; Copyright, Transp. All rights reserved.', 'transp'), date('Y')),
        'type'        => 'textarea',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      )
    );

	return apply_filters( 'transp_footer_options', $options );
}  
?>