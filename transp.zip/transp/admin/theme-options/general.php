<?php
function transp_general_options( $options = array() ){
	
	$options = array(
	  array(
        'id'          => 'main_logo',
        'label'       => esc_html__( 'Header Logo', 'transp' ),
        'desc'        => esc_html__( 'Header logo', 'transp' ),
        'std'         => TRANSPTHEMEURI . 'images/logo.svg',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'mobile_logo',
        'label'       => esc_html__( 'Responsive Logo', 'transp' ),
        'desc'        => esc_html__( 'Logo for responsive devices( mobile, tab etc )', 'transp' ),
        'std'         => TRANSPTHEMEURI . 'images/logo-white.svg',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'preloader',
        'label'       => esc_html__( 'Display Preloader', 'transp' ),
        'desc'        => '',
        'std'         => 'off',
        'type'        => 'on-off',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      )
	);

	return apply_filters( 'transp_general_options', $options );
}
?>