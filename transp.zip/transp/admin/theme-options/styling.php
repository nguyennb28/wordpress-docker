<?php
function transp_styling_options( $options = array() ){
	$options = array(
		array(
        'id'          => 'preset_color',
        'label'       => esc_html__( 'Preset Color', 'transp' ),
        'desc'        => esc_html__( 'Main preset color', 'transp' ),
        'std'         => '#FEC201',
        'type'        => 'colorpicker',
        'section'     => 'styling_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'      => array(
                array(
                'selector' => '',
                'property'   => 'background-color'
                ),
                array(
                'selector' => '',
                'property'   => 'color'
                ),
                array(
                    'selector' => '',
                    'property'   => 'border-color'
                ),
				array(
                    'selector' => '',
                    'property'   => 'border-top-color'
                ),
				array(
                    'selector' => '',
                    'property'   => 'border-bottom-color'
                ),
				array(
                    'selector' => '',
                    'property'   => 'border-left-color'
                )
            )
      ),
	  
	  array(
        'id'          => 'preset_color_2',
        'label'       => esc_html__( 'Secondary Preset Color', 'transp' ),
        'desc'        => esc_html__( 'Secondary preset color', 'transp' ),
        'std'         => '#303030',
        'type'        => 'colorpicker',
        'section'     => 'styling_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'      => array(
                array(
                'selector' => '',
                'property'   => 'background-color'
                ),
                array(
                'selector' => '',
                'property'   => 'color'
                ),
                array(
                    'selector' => '',
                    'property'   => 'border-color'
                )
            )
      )
    );

	return apply_filters( 'transp_styling_options', $options );
}  
?>