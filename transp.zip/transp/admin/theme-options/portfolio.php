<?php
function transp_portfolio_options( $options = array() ){
	$options = array(
	array(
        'id'          => 'portfolio_title',
        'label'       => esc_html__( 'Portfolio Header Title', 'transp' ),
        'desc'        => esc_html__( 'Portfolio page header title', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'portfolio_subtitle',
        'label'       => esc_html__( 'Portfolio Header Sub-Title', 'transp' ),
        'desc'        => esc_html__( 'Portfolio page header sub-title', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'portfolio_single_description',
        'label'       => esc_html__( 'Portfolio Single Header Description', 'transp' ),
        'desc'        => esc_html__( 'Portfolio single header description', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
		array(
        'id'          => 'portfolio_layout',
        'label'       => esc_html__( 'Portfolio layout', 'transp' ),
        'desc'        => esc_html__( 'Portfolio layout for portfolio page', 'transp' ),
        'std'         => 'full',
        'type'        => 'radio-image',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'full',
            'label'       => esc_html__( 'Full width', 'transp' ),
            'src'         => OT_URL . '/assets/images/layout/full-width.png'
          ),
          array(
            'value'       => 'ls',
            'label'       => esc_html__( 'Left sidebar', 'transp' ),
            'src'         => OT_URL . '/assets/images/layout/left-sidebar.png'
          ),
          array(
            'value'       => 'rs',
            'label'       => esc_html__( 'Right sidebar', 'transp' ),
            'src'         => OT_URL . '/assets/images/layout/right-sidebar.png'
          )
        )
      ),
      array(
        'id'          => 'portfolio_sidebar',
        'label'       => esc_html__( 'Portfolio Sidebar', 'transp' ),
        'desc'        => esc_html__( 'Select your portfolio sidebar', 'transp' ),
        'std'         => 'sidebar-1',
        'type'        => 'sidebar-select',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'portfolio_layout:not(full)',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'portfolio_single_title',
        'label'       => esc_html__( 'Portfolio Single Header Title', 'transp' ),
        'desc'        => esc_html__( 'Portfolio single header title', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'portfolio_single_subtitle',
        'label'       => esc_html__( 'Portfolio Single Header Sub-Title', 'transp' ),
        'desc'        => esc_html__( 'Portfolio single header sub-title', 'transp' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'portfolio_single_layout',
        'label'       => esc_html__( 'Portfolio single post layout', 'transp' ),
        'desc'        => esc_html__( 'Portfolio single post layout', 'transp' ),
        'std'         => 'full',
        'type'        => 'radio-image',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'full',
            'label'       => esc_html__( 'Full width', 'transp' ),
            'src'         => OT_URL . '/assets/images/layout/full-width.png'
          ),
          array(
            'value'       => 'ls',
            'label'       => esc_html__( 'Left sidebar', 'transp' ),
            'src'         => OT_URL . '/assets/images/layout/left-sidebar.png'
          ),
          array(
            'value'       => 'rs',
            'label'       => esc_html__( 'Right sidebar', 'transp' ),
            'src'         => OT_URL . '/assets/images/layout/right-sidebar.png'
          )
        )
      ),
    array(
        'id'          => 'portfolio_single_sidebar',
        'label'       => esc_html__( 'Single post Sidebar', 'transp' ),
        'desc'        => esc_html__( 'Single post sidebar', 'transp' ),
        'std'         => 'sidebar-1',
        'type'        => 'sidebar-select',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'single_layout:not(full)',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'portfolio_header_banner_type',
        'label'       => esc_html__( 'Header Banner Type', 'transp' ),
        'desc'        => esc_html__( 'Select your header banner type', 'transp' ),
        'std'         => 'portfolio_custom_image',
        'type'        => 'select',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'portfolio_bg_color',
            'label'       => esc_html__( 'Background Color', 'transp' ),
          ),
		  array(
            'value'       => 'portfolio_custom_image',
            'label'       => esc_html__( 'Custom Image', 'transp' ),
          )
        )
      ),
	  array(
        'id'          => 'portfolio_header_custom_color',
        'label'       => esc_html__('Select Color', 'transp'),
        'desc'        => '',
        'std'         => '#303030',
        'type'        => 'colorpicker',
		'section'     => 'portfolio_options',
        'class'       => '',
        'choices'     => array(),
        'operator'    => 'and',
        'condition'   => 'portfolio_header_banner_type:is(portfolio_bg_color)',
      ),
	  array(
        'id'          => 'portfolio_default_banner_image',
        'label'       => esc_html__( 'Background Image', 'transp' ),
        'desc'        => esc_html__( 'Background image', 'transp' ),
        'std'         => TRANSPTHEMEURI. 'images/banner.png',
        'type'        => 'upload',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'portfolio_header_banner_type:is(portfolio_custom_image)',
        'operator'    => 'and'
      ),
    );

	return apply_filters( 'transp_portfolio_options', $options );
}  
?>