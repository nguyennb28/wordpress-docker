<?php
function transp_calculate_cost_options( $options = array() ){
  $options = array(
    array(
      'id'          => 'pickup_delivery_locations',
      'label'       => esc_html__( 'Add Pickup/Delivery Locations', 'transp' ),
      'desc'        => '',
      'std'         => '',
      'type'        => 'list-item',
      'section'     => 'calculate_cost_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and',
      'settings'    => array(
        array(
          'id'          => 'location_name',
          'label'       => esc_html__( 'Location Name', 'transp' ),
          'desc'        => '',
          'std'         => '',
          'type'        => 'text',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and'
      )
      )
    ),
    array(
      'id'          => 'add_extra_services',
      'label'       => esc_html__( 'Add Extra Services', 'transp' ),
      'desc'        => '',
      'std'         => '',
      'type'        => 'list-item',
      'section'     => 'calculate_cost_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and',
      'settings'    => array(
        array(
          'id'          => 'extra_service_name',
          'label'       => esc_html__( 'Service Name', 'transp' ),
          'desc'        => '',
          'std'         => '',
          'type'        => 'text',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and'
        ),
        array(
          'id'          => 'extra_service_price',
          'label'       => esc_html__( 'Service Price', 'transp' ),
          'desc'        => '',
          'std'         => '',
          'type'        => 'text',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and'
        )
      )
    ),
    array(
      'id'          => 'pickup_delivery_commodities',
      'label'       => esc_html__( 'Add Commodities', 'transp' ),
      'desc'        => '',
      'std'         => '',
      'type'        => 'list-item',
      'section'     => 'calculate_cost_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and',
      'settings'    => array(
        array(
          'id'          => 'commodities_name',
          'label'       => esc_html__( 'Commodities Name', 'transp' ),
          'desc'        => '',
          'std'         => '',
          'type'        => 'text',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and'
      )
      )
    ),
    array(
      'id'          => 'calculate_dimention',
      'label'       => esc_html__( 'Dimensions Field', 'transp' ),
      'desc'        => '',
      'std'         => 'on',
      'type'        => 'on-off',
      'section'     => 'calculate_cost_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and'
    ),
    array(
      'id'          => 'calculate_width',
      'label'       => esc_html__( 'Weight Field', 'transp' ),
      'desc'        => '',
      'std'         => 'on',
      'type'        => 'on-off',
      'section'     => 'calculate_cost_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and'
    ),	  
    array(
      'id'          => 'calculate_cost',
      'label'       => esc_html__( 'Add Calculate Details', 'transp' ),
      'desc'        => '',
      'std'         => '',
      'type'        => 'list-item',
      'section'     => 'calculate_cost_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and',
      'settings'    => array(
        array(
          'id'          => 'calculate_country',
          'label'       => esc_html__('Select Pickup Location', 'transp'),
          'desc'        => '',
          'std'         => '',
          'type'        => 'select',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and',
          'choices'     => get_all_pickup_delivery_locations()
        ),
        array(
          'id'          => 'calculate_delivery',
          'label'       => esc_html__('Select Delivery Location', 'transp'),
          'desc'        => '',
          'std'         => '',
          'type'        => 'select',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and',
          'choices'     => get_all_pickup_delivery_locations()
        ),
        array(
          'id'          => 'calculate_commodities',
          'label'       => esc_html__('Select Commodities', 'transp'),
          'desc'        => '',
          'std'         => '',
          'type'        => 'select',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and',
          'choices'     => get_all_commodities()
        ),
        array(
          'id'          => 'max_weight',
          'label'       => esc_html__('Item Max Weight', 'transp'),
          'desc'        => esc_html__('Item max weight', 'transp'),
          'std'         => '',
          'type'        => 'text',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and',
          'choices'     => ''
        ),
        array(
          'id'          => 'item_price',
          'label'       => esc_html__('Item Price', 'transp'),
          'desc'        => esc_html__('Price Should be integer value(and currency will be woocommerce currency)', 'transp'),
          'std'         => '',
          'type'        => 'text',
          'rows'        => '',
          'post_type'   => '',
          'taxonomy'    => '',
          'min_max_step'=> '',
          'class'       => '',
          'condition'   => '',
          'operator'    => 'and',
          'choices'     => ''
        ),
        array(
          'id'          => 'select_product_to_connect',
          'label'       => esc_html__( 'Select Product to Connect', 'transp' ),
          'desc'        => esc_html__( 'All products will show here', 'transp' ),
          'type'        => 'custom-post-type-select',
          'post_type'   => 'product',
        )
      )
    )		
  );

  return apply_filters( 'transp_calculate_cost_options', $options );

}
?>