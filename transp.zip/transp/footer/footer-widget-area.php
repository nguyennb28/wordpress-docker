<?php
/**
 * footer widget area
 *
 *
 * @package WordPress
 * @subpackage transp
 * @since Transp 1.0.0
 */

$footer_widget_area = (function_exists('ot_get_option'))? ot_get_option('footer_widget_area', 'on') : 'on';
	
if( $footer_widget_area == 'on' ):
	$footer_widget_box = (function_exists('ot_get_option'))? ot_get_option('footer_widget_box', 4) : 4;
	$footer_widget_box_column_serial = (function_exists('ot_get_option'))? ot_get_option('footer_widget_box_column_serial', '3,3,3,3') : '3,3,3,3';
	$col_class = ''; ?> 
	
	<div class="footer-1">
		<div class="container">
			<div class="row">
				<?php for( $i = 1; $i <= $footer_widget_box; $i++ ):
					if( $footer_widget_box > 4 ){
						if( $i == 1 ){
							$col_class = ' width-23';
						} elseif( $i == 5 ) {
							$col_class = ' width-20';
						} else {
							$col_class = ' width-16';
						}					
					}

					$column_number = explode(',', $footer_widget_box_column_serial);
					$column_number = array_combine(range(1, count($column_number)), $column_number); 
					 
					$column_classes = $column_number[$i]. $col_class; 
					if ( is_active_sidebar( 'footer-'.$i ) ) : ?>
						<div class="col-lg-<?php echo esc_attr($column_classes); ?> col-md-6 footer-widget-area">
							<?php dynamic_sidebar( 'footer-'.$i ); ?>
						</div>
					<?php endif;
				endfor; ?>                
			</div>
		</div>
	</div>
<?php endif; ?>