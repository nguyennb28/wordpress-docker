<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 */
$footer_border_top = '';
$overwrite_footer_style = get_post_meta(get_the_ID(), 'overwrite_footer_style', true);
if($overwrite_footer_style == 'on'){
	$footer_style = get_post_meta(get_the_ID(), 'page_footer_style', true);
}else{
	$footer_style = (function_exists('ot_get_option'))? ot_get_option('footer_style', 'style1') : 'style1';
}

$footer_widget_area = (function_exists('ot_get_option'))? ot_get_option('footer_widget_area', 'on') : 'on';

if(is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) || is_active_sidebar( 'footer-widget-top' )):
	$top_padding = ' with-padding-top';
	$footer_border_top = ' footer-with-border-top';
else:
	$top_padding = ' no-padding-top';
endif;

if($overwrite_footer_style == 'on'){
	$footer_widget_top_area = get_post_meta(get_the_ID(), 'overwrite_footer_top_widget', true);
}else{
	$footer_widget_top_area = (function_exists('ot_get_option'))? ot_get_option('footer_widget_top_area', 'off') : 'off';
}

if($footer_widget_top_area == 'on'): ?>
	<?php if ( is_active_sidebar( 'footer-widget-top' ) ) : ?>
		<section class="bg-fixed bg-image banner-section division">
			<div class="container">
				<div class="row d-flex align-items-center">
					<!-- TEXT BLOCK -->	
					<div class="col-lg-6 offset-lg-3">
						<div class="banner-5-txt text-center">
							<?php dynamic_sidebar( 'footer-widget-top' ); ?>
						</div>
					</div>	<!-- END TEXT BLOCK -->	
				</div>	  <!-- End row -->	
			</div>	   <!-- End container -->
		</section>	<!-- END BANNER-5 -->
	<?php endif;
endif;
?>
	<footer class="footer">
		<?php			
		if($footer_widget_area == 'on'):
			if(is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) || is_active_sidebar( 'footer-widget-top' )): ?>

				<?php get_template_part('footer/footer-widget-area', ''); ?>
				
		<?php endif;
		endif; ?>

		<div class="footer-2 <?php echo esc_attr($top_padding); ?>">
			<div class="container">
				<!-- BOTTOM FOOTER -->
				<div class="footer-bottom<?php echo esc_attr($footer_border_top); ?>">
					<div class="row row-cols-1 row-cols-md-2 d-flex align-items-center">
						<div class="col">
							<div class="footer-copyright color-grey-300 font-md">
								<?php
								$copyright_text = (function_exists('ot_get_option'))? ot_get_option( 'copyright_text', sprintf(esc_html__('%1$s &copy; Copyright, Transp. All rights reserved.', 'transp'), date('Y'))) : sprintf(esc_html__('%1$s &copy; Copyright, Transp. All rights reserved.', 'transp'), date('Y'));
								echo wp_kses(do_shortcode($copyright_text), array('div'=>array('class'=>array(), 'id'=>array()), 'a'=>array('class'=>array(), 'title'=>array(), 'href'=>array()), 'p'=>array('class'=>array())));
								?>
							</div>
						</div>
						<div class="col">
							<?php											
							wp_nav_menu(array(
							'theme_location'  => 'footer-menu',
							'menu_class'      => 'text-end menu-bottom',
							'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
							'fallback_cb'     => '',
							'container'       => '',
							'depth'			  => 1
							));
							?>
						</div>
					</div>  <!-- End row -->
				</div>	<!-- BOTTOM FOOTER -->
			</div>
		</div>
			
	</footer>	<!-- FOOTER-4 -->
</div>
<!-- Wrapper Ends -->
  <?php wp_footer(); ?>
</body>
</html>